# Rainbow SDK

[![npm version](https://badge.fury.io/js/@rainbow-me%2Fsdk.svg)](https://www.npmjs.com/package/@rainbow-me/sdk) [![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/license/mit)

The Rainbow SDK provides typed APIs for account delegation, EVM calls, Solana instructions, routes, policy management, authority keys, and recovery.

## Install

Install the package together with its required peer dependencies:

```bash
yarn add @rainbow-me/sdk viem@^2.55.2 @storesjs/stores@^0.8.6
```

Optional peers:

- `react` for `useDelegations`, `useDelegationDisabled`, and `useWillDelegate`
- `ethers` if you pass ethers client inputs instead of viem clients

## Configure once

Call `configure(...)` before using namespace methods or hooks.

```ts
import { configure } from '@rainbow-me/sdk';

configure({
  platformClient,
  logger,
  getCurrentAddress,
  storeOptions,
  readAccountCode,
  resolveDelegationCapability,
  relayService,
});
```

Required services:

- `platformClient`
- `logger`
- `getCurrentAddress`

Optional services:

- `storeOptions`
- `readAccountCode`
- `resolveDelegationCapability`
- `relayService`

Configure `relayService` for routes and status reads. It also handles sponsorship for calls and instructions, and ERC-20 fee payment for calls.

## Public surface

Primary entry points:

- `configure`
- `delegation`
- `execute`
- `policy`
- `factor`
- `authority`
- `recovery`
- `useDelegations`
- `useDelegationDisabled`
- `useWillDelegate`

EVM transaction methods accept either:

- viem input: `{ walletClient, publicClient }`
- ethers input: `{ signer, provider, chainId }`

Solana methods use a `SolanaClient` with an RPC and a signer.

## Common paths

### Exact calls

Prepare when you need review before submission:

```ts
const prepared = await execute.prepare.calls({
  walletClient,
  publicClient,
  chainId,
  calls,
  atomic: true,
});

if (prepared.kind === 'calls.wallet') {
  // review wallet transactions and delegation authorization if needed
}

const result = await execute.calls(prepared, {
  walletClient,
  publicClient,
});
```

If you do not need review first, pass the call parameters directly to `execute.calls(...)`.

### Solana instructions

Prepare when the application needs to review the Solana transaction before signing:

```ts
import { execute, SolanaCluster } from '@rainbow-me/sdk';

const solanaClient = { rpc, signer };
const prepared = await execute.prepare.instructions({
  account: signer.address,
  rpc,
  cluster: SolanaCluster.Devnet,
  instructions,
});

const result = await execute.instructions(prepared, solanaClient);
```

If review is unnecessary, call `execute.instructions(...)` directly with `{ cluster, instructions, rpc, signer }`.

### Routes

Routes require explicit preparation to obtain a provider quote:

```ts
const prepared = await execute.prepare.route({
  account: walletClient.account.address,
  publicClient,
  source: {
    asset: {
      location: 'evm',
      kind: 'erc20',
      chainId: baseChainId,
      address: sourceToken,
    },
    amount: {
      kind: 'exact-input',
      input: sourceAmount,
    },
  },
  destination: {
    asset: {
      location: 'solana',
      kind: 'native',
      cluster: SolanaCluster.Mainnet,
    },
    recipient: solanaRecipient,
  },
});

const result = await execute.route(prepared, {
  walletClient,
  publicClient,
});

const status = await execute.status({
  executionId: result.executionId,
});
```

Prepare the route with the account that holds the source asset. Execute it with EVM clients for an EVM or platform source, or with a `SolanaClient` for a Solana source.

## Docs

- [`src/context/README.md`](src/context/README.md): dependency injection and client normalization
- [`workers/relay-reference/README.md`](workers/relay-reference/README.md): reference relay backend
- [`demo/relay-link-poc/README.md`](demo/relay-link-poc/README.md): live Relay.link demo and scenario runner

Delegation contract mappings live in [`src/contract/addresses.ts`](src/contract/addresses.ts).

## Development

```bash
yarn install
yarn build
yarn test
yarn verify
```

Useful demos:

- `yarn demo:passkey`
- `yarn demo:passkey:lan`
- `yarn demo:integrity`
- `yarn demo:relay-link-poc`
