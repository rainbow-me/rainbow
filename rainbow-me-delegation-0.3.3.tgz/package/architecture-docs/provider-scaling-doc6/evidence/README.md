# Doc 6 evidence index

- `0x/notes.md`
- `0x/live/2026-03-16-gasless-price-no-api-key.json`
- `gelato/notes.md`
- `gelato/live/2026-03-16-status-invalid-taskid.json`
- `gelato/live/2026-03-16-status-not-found.json`
- `across/notes.md`
- `across/live/2026-03-16-swap-approval-response.json`
- `across/live/2026-03-16-deposit-status-response.json`

This index is the evidence root for `architecture-docs/5-provider-model-scaling.md`.
