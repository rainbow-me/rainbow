# Gelato Relay SDK (Deprecated)

> **This package is deprecated.** Please use [`@gelatocloud/gasless`](https://www.npmjs.com/package/@gelatocloud/gasless) instead.

## Migration

Install the new package:

```bash
npm install @gelatocloud/gasless
```

See the [@gelatocloud/gasless documentation](https://www.npmjs.com/package/@gelatocloud/gasless) for usage instructions.
