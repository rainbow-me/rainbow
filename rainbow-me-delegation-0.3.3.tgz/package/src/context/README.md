# Context And Dependency Injection

This library uses one runtime container (`configure`/`getServices`) and one action-definition primitive (`defineAction`) to keep internal action modules focused on domain inputs while injecting platform dependencies and normalizing client shapes for the public namespace API.

## Architecture

```text
context/
├── types.ts         # service contracts and configure() input types
├── container.ts     # configure() + getServices()
├── clients.ts       # viem/ethers input normalization
├── defineAction.ts  # typed wrapper for injection + normalization
└── index.ts         # public exports
```

## Service Model

`configure(configuration)` stores services globally and initializes the delegation status store.

Required services:

- `platformClient`
- `logger`
- `getCurrentAddress`

Optional services:

- `storeOptions`
- `readAccountCode`
- `resolveDelegationCapability`
- `intentRelay`
- `resolveRelayQuoteSigner`

```ts
configure({
  platformClient,
  logger,
  getCurrentAddress,
  storeOptions,
  readAccountCode,
  resolveDelegationCapability,
  intentRelay,
  resolveRelayQuoteSigner,
});
```

`readAccountCode` is a chain-aware runtime-code reader used by `delegation.isSupported`, `delegation.willDelegate`, and `execute.prepare.calls(...)` to correct stale backend `NOT_DELEGATED` states with onchain indicator truth.

`resolveDelegationCapability` is an optional chain-aware capability resolver for local/staging deployments where capability runtime hash or feature flags differ from the production lock.

`intentRelay` is an optional relay integration used by managed `execute.prepare.calls(...)`, `execute.prepare.route(...)`, `execute.calls(...)`, `execute.route(...)`, and `execute.status(...)`. Its `transport` owns the relay lifecycle operations (`prepare`, `execute`, `submitWalletResults`, `getStatus`). When a relay exact-call flow requires client-owned immutable prepare expectations before `transport.prepare(...)`, the integration may also provide `buildPrepareExpectations(...)` so the SDK derives those facts before prepare runs.

`resolveRelayQuoteSigner` is an optional temporary request-scoped quote-signer trust override (`expectedQuoteSigner`) used only when SDK-pinned profiles are unavailable for a chain.

## Injection Model

`defineAction` wraps an action and transforms its external call signature:

- injects configured services (`platformClient`, `logger`, etc.)
- injects normalized viem clients (`walletClient`, `publicClient`)
- removes injected keys from the caller-facing params
- accepts either viem or ethers client input at the call site

```ts
type Externalize<P extends object> = {
  [K in keyof P as K extends keyof (ClientOutput & Services) ? never : K]: P[K];
} & ClientInput;

export function defineAction<P extends object, R>(
  fn: (params: P) => R,
): (params: Externalize<P>) => R;
```

## Client Input Shapes

Bound functions accept exactly one of:

- viem input: `{ walletClient, publicClient }`
- ethers input: `{ signer, provider, chainId }`

Ethers input is normalized into viem clients internally. For ethers input, signer must expose `privateKey` and provider must expose an RPC URL.

## Runtime Validations

The context layer enforces invariants close to the boundary:

- `configure` must be called before bound functions execute
- viem `walletClient` must include an account
- ethers signer/provider must resolve to the same RPC source
- when `chainId` is provided, it must match both normalized client chains (if present)

These checks ensure action code sees a coherent, fully-normalized dependency surface.
