# Relay Architecture

`src/relay` is the SDK's relay correctness core.

It owns the local part of one question:

Given a worker-signed prepared execution and an available direct path, what should the SDK verify, what should it sign, when should it keep going through relay, and when should it fall back?

## What this directory owns

- intent, quote, and response-binding hashes
- prepare-package validation
- quote-time checks
- relay failure classification and fallback policy
- lifecycle orchestration over `prepare`, `execute`, `submitWalletResults`, and `getStatus`
- unified status reduction
- idempotency helpers and circuit-breaker helpers

Provider-specific session semantics stay in the worker.

## Core objects

The shared relay flow uses three objects:

1. `PreparedRelayExecution`
2. `RelayExecutionUpdate`
3. `RelayTransport`

`PreparedRelayExecution` is the signed worker artifact returned by `prepare`. It contains:

- `prepareCommitment`
- `providerContinuation`
- `walletProgram`
- `walletCursor`
- `executionId`

`RelayExecutionUpdate` is the worker-owned execute-time response. It carries one normalized status. When status is `AWAITING_WALLET`, it also carries a newly signed `PreparedRelayExecution`.

The SDK derives the current wallet request from `preparedExecution.walletProgram[preparedExecution.walletCursor]`. Wallet-results submissions may also include later results from the same approved wallet program.

`providerContinuation` stays opaque here. Shared code hashes and verifies it, but the worker owns its meaning.

`RelayTransport` is the SDK integration boundary:

```ts
type RelayTransport<PrepareContext, Prepared, ExecuteRequest = Prepared> = {
  prepare: (context: PrepareContext) => Promise<Prepared>;
  execute: (request: ExecuteRequest) => Promise<RelayExecutionUpdate<Prepared>>;
  submitWalletResults: (
    request: RelayWalletResultsRequest,
  ) => Promise<RelayExecutionUpdate<Prepared>>;
  getStatus: (
    executionId: RelayExecutionId,
  ) => Promise<RelayExecutionUpdate<Prepared>>;
};
```

## Lifecycle

`lifecycle.ts` runs one deterministic loop:

1. call `transport.prepare(...)`
2. validate the returned `PreparedRelayExecution`
3. sign `executionDigest`
4. call `transport.execute(...)`, optionally with wallet results starting at `walletCursor`
5. if the worker returns `AWAITING_WALLET`, derive the current wallet request from `preparedExecution.walletProgram` and `walletCursor`, execute it, and call `submitWalletResults(...)`, again optionally including later results from the same approved wallet program
6. otherwise poll `getStatus(...)` until terminal state or another wallet boundary

The SDK executes only:

- `signAuthorization`
- `signMessage`
- `signTypedData`
- `sendTransaction`

Provider session state, step progression, `check`, and `post` stay outside this directory. The client never sends provider session updates back to the worker. It sends only shared wallet results for the approved `walletProgram`, and the worker decides when stored later results become current.

## Verification model

Prepare verification checks four things before the SDK signs execute proof:

1. quote time is still acceptable
2. the quote digest still matches local intent bindings and relay domain
3. the worker-signed binding still matches the returned `providerContinuation` and `walletCursor`
4. the recovered quote signer matches the expected signer for this request

`feeDerivationHash` binds the full fee-derivation contract into quote terms, so the SDK verifies both the declared fee model and the resulting `maxFee`. The default relay fee policy also caps `adjustmentBps` at 1%; absolute fee caps remain caller-owned because they vary by token, route, and product economics. `executionDigest` binds `walletProgramHash`, so wallet-program mutation is an integrity failure rather than a transport update.

## Fallback model

Fallback policy is deterministic and class-based:

- integrity failures do not auto-fallback
- quote-expiry failures allow one bounded reprepare before guarded direct fallback
- transport failures may allow guarded direct fallback
- fee-mode mismatches fail closed

Once the wallet has already acted, relay submission ambiguity no longer uses reprepare or direct fallback. The SDK recovers the existing relay execution by `executionId` and otherwise keeps the relay leg pending or fails closed.

The SDK keeps one status model across relay and direct legs so callers do not invent their own precedence rules.

## Integration entry points

Public relay-backed execution enters through:

- `execute.prepare.calls(...)`
- `execute.prepare.route(...)`
- `execute.calls(...)` when the calls planner chooses a managed plan
- `execute.route(...)`
- `execute.status(...)`

Internal owners for those paths:

- `src/actions/internal/managedExecution.ts`
- `src/actions/internal/callsPlanner.ts`
- `src/actions/internal/relayExecution.ts`
- `src/actions/internal/preflightRelay.ts`

Wallet-plan fallback stays on the same direct execution stack used by `execute.calls(...)`.

## File map

- `intentHash.ts`: call and intent hashing
- `quoteDigest.ts`: quote digest model
- `responseDigest.ts`: prepare-response binding
- `walletProgram.ts`: wallet-program hashing and cursor reads
- `walletProgramExecution.ts`: local wallet-program execution starting at one cursor
- `quoteTime.ts`: local quote-time acceptance
- `prepareValidation.ts`: prepared execution validation
- `transport.ts`: transport contract and status polling
- `lifecycle.ts`: relay lifecycle loop
- `fallbackPolicy.ts`: fallback decisions
- `executionFlow.ts`: relay/direct flow reduction
- `statusReducer.ts`: normalized status model
- `idempotency.ts`: deterministic id generators
- `circuitBreaker.ts`: quarantine decision helper

## Change discipline

Treat this folder as protocol logic, not utility code.

Before changing behavior:

1. update lock docs if semantics change (`docs/locks/RAINBOW_RELAY_DESIGN_LOCKED_V4.md`)
2. add/update deterministic tests in this folder
3. verify relay integration tests:
   - `src/actions/internal/preflightRelay.test.ts`
   - `src/actions/internal/relayExecution.test.ts`
   - `src/actions/managedExecution.runtime.test.ts`

Do not land relay behavior changes that "look equivalent" but alter fallback or integrity semantics without lock + test updates.
