# Relay Intent Model

This README describes the shared relay contract used by `src/relay`. It covers only the facts shared between SDK and worker. Provider-specific meaning stays with the worker.

## Shared execution package

Prepared relay execution has six top-level facts:

1. `prepareCommitment`
2. `sourceExecution`
3. `providerContinuation`
4. `walletProgram`
5. `walletCursor`
6. `executionId`

`prepareCommitment` is the signed worker commitment. `sourceExecution` is the exact source-chain call batch and value the worker is asking the user to authorize and later submit. `providerContinuation` is the current provider-owned continuation package.

`walletProgram` is the exact wallet request sequence approved by the user's execute proof. It excludes the execute-proof signature itself. `walletCursor` is the next wallet-program index the worker is asking the SDK to execute. `executionId` is the stable public execution handle.

## Signed facts

`prepareCommitment.providerTerms` carries:

- `relayDomain`
- `quoteTerms`
- `feeDerivation`

`quoteTerms` carries the stable economic facts:

- `quoteId`
- `issuedAt`
- `expiresAt`
- `maxClockSkewSec`
- `feeToken`
- `maxFee`
- `feeDerivationHash`
- `sponsored`

`feeDerivationHash` binds the full fee-derivation contract: kind, source id, policy version, fee components, subsidized amount, adjustment bps, adjustment kind, and rounding mode.

`prepareCommitment.responseBinding` signs:

- `quoteDigest`
- `executionDigest`
- `callsHash`
- `providerContinuationHash`
- `walletCursor`
- `clientRequestId`

`quoteDigest` binds two different shared facts:

- `prepareIntentHash`: the caller-owned prepare intent sent into `prepare`
- `callsHash`: the exact prepared source execution the worker returned

`executionDigest` already commits to `walletProgramHash`, so the user signs the approved wallet program once. It remains the exact-execution approval digest, not the caller-intent digest. If the worker later advances to a new provider frontier, it keeps the same provider terms, `walletProgram`, and `executionId`, then signs a new `providerContinuationHash` and/or `walletCursor`. That is execute admission proof and it does not change when the worker returns a new current execution package.

## Shared boundary

`providerContinuation` is opaque in shared code:

```ts
type ProviderContinuation = JsonObject & {
  readonly type: string;
};
```

Provider-specific parsing and session progression stay in the worker.

## Execution model

Two execution families exist:

- direct derived submission: wallet-owned authority after execute admission, provider-owned submission after that
- quote-driven provider session: interactive worker-owned path after execute admission

When the worker reaches a wallet boundary, it returns:

- status `AWAITING_WALLET`
- a newly signed `PreparedRelayExecution`
- `preparedExecution.walletProgram`
- `preparedExecution.walletCursor`

The SDK derives the current wallet request from `preparedExecution.walletProgram[preparedExecution.walletCursor]`. That wallet request is always one of:

- `signAuthorization`
- `signMessage`
- `signTypedData`
- `sendTransaction`

The shared layer does not learn provider step graphs, `requestId`, `check`, or `post`. It sees only the signed execution package and the immutable wallet program plus cursor.

Wallet-results submissions always start at the current cursor. They may also include later results from the same approved wallet program. The worker stores those later results and uses them when the cursor reaches them.

## Identities

These ids stay distinct:

- `executionId`
- `quoteId`
- provider `requestId`
- protocol `orderId`

`executionId` is the shared public execution handle. Provider `requestId` stays provider-local state. The shared status model does not surface it.

## Relay-link in the current worker

Relay-link currently uses:

- `relay-link.direct.v0`
- `relay-link.step-program.v0`

`relay-link.direct.v0` is the current signed-execute direct-submission family. Future direct families should stay separate from that continuation instead of being added as branches inside its runtime/session model.

The step program preserves ordered Relay steps and items, raw step-item `data`, `check`, protocol `v2` metadata, and the current `frontier` cursor, the provider's pointer to the next step item.

## Crash recovery

Crash recovery has one rule:

- persist the wallet result before any provider interaction that uses it

Transactions resume from persisted `txHash` plus provider `check`. Signature-step replay uses the same endpoint, request body, and signature from the persisted wallet result and the same signed execution package that requested it, then checks provider progress through `check`. If that replay contract cannot be proven, fail closed.
