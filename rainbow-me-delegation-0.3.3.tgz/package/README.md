# Rainbow Wallet SDK

[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)

TypeScript SDK for Rainbow account delegation, exact-call execution, policy management, authority keys, recovery flows, and managed routed execution.

## What the SDK owns

- delegation queries and mutations
- exact-call execution planning and submission
- managed exact-call and routed execution with local verification and status
- policy reads and mutations
- authority and recovery helpers
- optional React hooks for delegation state

## Install

Install the package together with its required peer dependencies:

```bash
yarn add @rainbow-me/delegation viem@^2.38.0 @storesjs/stores@^0.8.6
```

Optional peers:

- `react` for `useDelegations`, `useDelegationDisabled`, and `useWillDelegate`
- `ethers` if you pass ethers client inputs instead of viem clients

## Configure once

Call `configure(...)` before using namespace methods or hooks.

```ts
configure({
  platformClient,
  logger,
  getCurrentAddress,
  storeOptions,
  readAccountCode,
  resolveDelegationCapability,
  relayService,
});
```

Required services:

- `platformClient`
- `logger`
- `getCurrentAddress`

Optional services:

- `storeOptions`
- `readAccountCode`
- `resolveDelegationCapability`
- `relayService`

`relayService` is only needed for managed execution: `execute.prepare.route(...)`, `execute.route(...)`, `execute.status(...)`, and any exact-call flow where `execute.prepare.calls(...)` or `execute.calls(...)` chooses `calls.managed`.

## Public surface

Root exports:

- `configure`
- `delegation`
- `execute`
- `policy`
- `factor`
- `authority`
- `recovery`
- `useDelegations`
- `useDelegationDisabled`
- `useWillDelegate`

Namespace transaction methods accept either:

- viem input: `{ walletClient, publicClient }`
- ethers input: `{ signer, provider, chainId }`

Ethers inputs are normalized to viem internally.

## Common paths

### Exact calls

Prepare when you need review before submission:

```ts
const prepared = await execute.prepare.calls({
  walletClient,
  publicClient,
  chainId,
  calls,
  requirements: {
    atomic: 'preferred',
  },
});

if (prepared.kind === 'calls.wallet') {
  // review wallet transactions and delegation authorization if needed
}

const result = await execute.calls(prepared);
```

If you do not need review first, call `execute.calls(...)` directly with the raw params.

### Routed execution

Prepare is mandatory because route execution is quote-bound and reviewable:

```ts
const prepared = await execute.prepare.route({
  walletClient,
  publicClient,
  chainId,
  route,
});

const result = await execute.route(prepared);

const status = await execute.status({
  executionId: result.executionId,
});
```

Managed execution does four things:

- verifies a worker-signed `PreparedRelayExecution`
- asks the user to sign `executionDigest` once
- keeps provider session state in the worker
- uses wallet capabilities only when the worker explicitly asks for one of: `signMessage`, `signTypedData`, or `sendTransaction`

Direct fallback stays inside the same execution flow.

## Docs

- [`src/context/README.md`](src/context/README.md): dependency injection and client normalization
- [`src/relay/README.md`](src/relay/README.md): relay correctness core
- [`src/relay/intent-model/README.md`](src/relay/intent-model/README.md): shared relay intent model
- [`workers/relay-reference/README.md`](workers/relay-reference/README.md): reference relay backend
- [`demo/relay-link-poc/README.md`](demo/relay-link-poc/README.md): live Relay.link demo and scenario runner

Delegation contract mappings live in [`src/contract/addresses.ts`](src/contract/addresses.ts).

## Development

```bash
yarn install
yarn build
yarn test
yarn verify
```

Useful demos:

- `yarn demo:passkey`
- `yarn demo:passkey:lan`
- `yarn demo:integrity`
- `yarn demo:relay-link-poc`
