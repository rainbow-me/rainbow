# Archived planning artifacts

This folder stores superseded planning/audit markdown artifacts to reduce
active-path ambiguity while preserving history.

Active architecture authority is now in:

- `docs/locks/RAINBOW_RELAY_DESIGN_LOCKED_V3.md`
- `docs/locks/RAINBOW_CONTRACT_STACK_LOCKED_V3.md`
- `docs/locks/RAINBOW_DESIGN_SECOND_DEEP_PASS_AUDIT.md`
- `docs/locks/RAINBOW_DESIGN_LOCK_MANIFEST_2026-02-20.md`

Archived sources are retained as historical references only.
