# Phase 0 Baseline Artifacts

Generated on: 2026-02-20

## Artifacts

- `invariants.md`: current delegation and execution invariants from code/tests
- `contract-capability-report.md`: chain-level deployed contract capability probe report
- `runtime-metrics.md`: local reproducible baseline metrics and bounds

## Raw evidence logs

- `test-run-core.log`
- `test-run-boundaries.log`
- `contract-capability-probe.log`
- `contract-capability-probe-alt.log`
- `metrics-typecheck.txt`
- `metrics-lint.txt`
- `metrics-circular.txt`

## Reproduction commands

```bash
npx -y node@22 ./node_modules/vitest/vitest.mjs run \
  src/actions/executeBatchedTransaction.test.ts \
  src/actions/executeDelegation.test.ts \
  src/actions/executeRevokeDelegation.test.ts \
  src/actions/supportsDelegation.test.ts \
  src/actions/willDelegate.test.ts \
  src/stores/delegationStatusStore.test.ts \
  src/stores/optimisticUpdates.test.ts \
  src/actions/internal/executeTransaction.test.ts \
  --reporter verbose

npx -y node@22 ./node_modules/vitest/vitest.mjs run \
  src/context/container.test.ts \
  src/context/defineAction.test.ts \
  src/context/clients.test.ts \
  src/actions/getDelegations.test.ts \
  src/actions/shouldRevokeDelegation.test.ts \
  src/actions/prepareBatchedTransaction.test.ts \
  --reporter verbose

npx -y node@22 $(which yarn) typecheck
npx -y node@22 $(which yarn) lint
npx -y node@22 $(which yarn) lint:circular
```

