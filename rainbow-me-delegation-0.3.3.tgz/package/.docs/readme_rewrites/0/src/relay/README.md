# Relay Module

`src/relay` is the SDK's relay correctness core.

It is the part of the system that answers a narrow but consequential question:

> **Given a prepared relay package, a local execution request, and a possible direct fallback path, what is the one correct decision and status outcome?**

That question sounds smaller than it is.
In practice it includes:

- whether the backend's `Prepare` response is about the request the client
  actually made
- whether the backend cryptographically committed to the same execution context
  the client is about to authorize
- whether relay may proceed
- whether direct fallback is allowed if relay fails
- how relay and direct legs collapse into one status model without caller-side
  guesswork

This module exists so those answers are **centralized, deterministic, and not
provider-specific**.

## If you only remember one thing

**Relay transport is pluggable. Relay correctness is not.**

A backend adapter may change.
Relay.link may change.
A future provider may replace both.

But the following must remain fixed:

- what a prepared relay commitment means
- how that commitment is verified before execution
- how failures map to fallback decisions
- how relay and direct outcomes reduce to one public status contract

If a change makes any of those backend- or provider-dependent, it is a design
regression.

## Why this module exists

Direct execution already had a correct model:

- the client knew what it was about to execute
- the chain enforced the final runtime constraints
- there was no backend `Prepare` surface between intent and execution

Relay introduces two new risks.

### 1. Trust drift

A relay backend can now contribute values the client cannot derive locally:

- sponsorship mode
- fee terms
- quote context
- validity window
- in some flows, even the payload the user signs

If the SDK treats those values as ordinary JSON, the backend becomes a trusted
party by default.

This module prevents that by requiring `Prepare` to be a signed commitment and
by validating that commitment against client-local intent before relay execution
proceeds. `Prepare` is not a suggestion. It is a commitment.

### 2. Fallback drift

Once relay exists, every caller is tempted to reinvent:

- error classification
- retry behavior
- quote-expiry handling
- direct fallback conditions
- status precedence rules

That produces a system where different call sites react differently to the same
failure.

This module prevents that by making fallback and status reduction centralized
and class-based.

## What this module owns

`src/relay` owns the parts of the relay system that must not vary by provider or
caller.

It owns:

- relay binding hashes
- prepare-response signature verification
- quote-time acceptance
- fee-derivation verification
- failure classification
- deterministic fallback policy
- relay lifecycle orchestration
- unified status reduction
- idempotency and circuit-breaker helpers

It does **not** own:

- provider-specific HTTP contracts
- backend pricing logic
- quote discovery
- sponsorship business policy
- application retry UX
- onchain policy authority

That split is deliberate:

- adapters own provider integration
- the runtime owns onchain authority
- `src/relay` owns pre-sign / pre-execute correctness

## The execution path in one diagram

```text
execute.relay(...)
  │
  ├─ resolve delegation state
  ├─ optionally preflight policy
  │
  └─ run relay lifecycle
      │
      ├─ transport.prepare({ chainId })
      ├─ preflightRelay(...)
      │    ├─ trust guards
      │    └─ validatePreparedQuote(...)
      │
      ├─ transport.execute(prepared)
      ├─ poll transport.getStatus(bundleId)
      │
      └─ if relay fails, apply deterministic fallback policy
           and optionally execute direct path

→ reduce relay and direct legs into one ExecutionFlowOutput
```

The critical point is where preflight sits:

**relay execution is gated on verification.**
No provider execute call should happen unless the SDK has already proved the
prepared commitment is consistent with local intent.

## The prepared relay commitment

The relay path uses one prepared artifact shape, returned by
`Transport<RelayInput>.prepare(...)`.

At a high level it contains:

- the relay domain (`relayId`, `relayVersion`, `environment`, `chainSetHash`,
  `quoteSigner`)
- the quoted terms (`quoteId`, validity window, fee terms, sponsorship flag)
- the signed binding (`quoteDigest`, `executionDigest`, `callsHash`,
  `clientRequestId`)
- the backend signature over that binding
- fee-derivation metadata needed for local arithmetic checks
- optional binding hashes for policy/runtime/nonce-lane parity

The outer signature envelope is EIP-712 typed data:

- **domain name:** `RainbowRelayPrepare`
- **domain version:** `1`
- **message fields:**
  - `quoteDigest`
  - `executionDigest`
  - `callsHash`
  - `clientRequestId`

The important architectural point is that the EIP-712 envelope is only the
outer attestation format. The real semantics live in the digests and in the
verification rules that recompute them locally.

## File map

### Commitment and verification surface

- `intentHash.ts` — call hashing and full execution-envelope hashing
- `quoteDigest.ts` — quote/domain digest
- `responseDigest.ts` — EIP-712 prepare binding digest and signer recovery
- `quoteTime.ts` — validity-window evaluation
- `feeDerivation.ts` — max-fee derivation and policy-bounds checks
- `prepareValidation.ts` — ordered validation of a prepared quote

### Lifecycle and fallback surface

- `fallbackPolicy.ts` — failure classification and class → decision mapping
- `lifecycle.ts` — prepare / execute / getStatus orchestration
- `executionFlow.ts` — relay + direct outcome resolution
- `statusReducer.ts` — unified status reduction
- `transport.ts` — adapter contract and polling model

### Operational helpers

- `idempotency.ts` — stable idempotency helpers
- `circuitBreaker.ts` — relay quarantine threshold evaluation helpers

## The invariants this module enforces

These are the invariants that define the module.
If a change weakens any of them, it should be treated as a regression.

### Integrity failures do not auto-fallback

If the prepared commitment cannot be verified, the system does not continue as
if relay merely had a flaky network. Integrity failures mean the trust boundary
itself failed.

### Fallback is sponsorship-safe

Direct fallback is only allowed when it does not silently degrade the user's
payment semantics.

A quote that was promised as sponsored must not quietly turn into a user-paid
direct execution merely because relay infrastructure failed.

### Fallback is class-based, not ad hoc

Quote expiry, transport failure, sponsorship-required failure, and integrity
failure are different classes. They do not all deserve the same response.

### Relay and direct reduce to one status model

Callers should not have to invent local precedence rules for hybrid execution
paths.

### Adapters are replaceable; semantics are not

Backends may translate different provider shapes into the transport contract.
What they may not do is redefine the meaning of a valid prepare commitment or
of fallback safety.

## Validation order

`preflightRelay(...)` applies the relay trust model in two stages.

### Stage 1: trust guards

Before digest validation runs, the SDK checks the fields that the caller pins
up front:

- expected quote signer
- expected chain-set hash
- optional required sponsorship mode

These checks answer:

> “Is this prepared object even about the request I made?”

They happen before signature verification because the SDK should not validate a
signature over the wrong domain baseline.

### Stage 2: prepared-quote validation

`validatePreparedQuote(...)` then applies ordered validation:

1. quote time acceptance
2. fee-derivation hash equivalence
3. derived max-fee equivalence and policy bounds
4. quote digest equivalence
5. calls-hash equivalence
6. execution-digest equivalence
7. client-request-id equivalence
8. prepare-signature authenticity against the expected quote signer

If any step fails, relay does not proceed.

The point is not merely “was this signed?”
The point is “was this signed **and** is it the same request, the same call
sequence, the same quote context, and the same execution envelope?”

## Why the digest set is split

The relay binding keeps three digests explicit because they bind different
surfaces with different ownership.

### `callsHash`

This is the stable commitment to ordered call tuples.
It is what makes call-level continuity explicit.

### `executionDigest`

This binds the execution authorization surface:

- chain
- account
- delegation state
- nonce lane
- calls
- policy/runtime bindings
- fee terms
- client request identity

### `quoteDigest`

This binds the relay commitment surface:

- relay identity
- relay version
- environment
- chain-set context
- quote signer
- intent bindings
- quote terms

The split matters because these are not the same object.
A change to relay context can leave the execution authorization surface intact
and still be a protocol violation. That is why `quoteDigest` exists separately
rather than being collapsed into one giant opaque hash.

## Fallback policy

`fallbackPolicy.ts` defines the only allowed decision table.

Current logic is intentionally strict:

- **integrity failure** → `NO_AUTO_FALLBACK`
- **quote expiry** → `REPREPARE_ONCE`, then guarded direct fallback if
  sponsorship semantics are preserved
- **transport failure** → guarded direct fallback only if sponsorship semantics
  are preserved
- **sponsorship required** → `FAIL_CLOSED`
- **unknown failure** → `FAIL_CLOSED`

The key subtlety is that guarded fallback applies to both quote-expiry and
transport failures. The governing invariant is not “network error means try
something else.” It is “never silently worsen payment semantics.”

## Unified status model

Relay execution can produce states that a direct-only API never has to think
about:

- relay accepted but not yet submitted
- relay submitted and pending confirmation
- relay failed, direct succeeded
- relay succeeded after previous relay transport instability

This module turns those into one status contract:

- `SUBMITTING`
- `PENDING`
- `CONFIRMED_RELAY`
- `CONFIRMED_DIRECT`
- `FAILED`

with provenance:

- `executionPath`: `relay`, `direct`, or `hybrid`
- relay bundle ID
- direct tx hash
- per-leg failure codes

This matters because status is part of correctness, not just part of UI.
If two callers derive different interpretations of the same relay/direct leg
combination, the system is no longer coherent.

## The transport contract

The transport surface is intentionally minimal:

```ts
type Transport<TPrepared> = {
  prepare: (context: { chainId: number }) => Promise<TPrepared>;
  execute: (prepared: TPrepared) => Promise<{ bundleId: string }>;
  getStatus: (bundleId: string) => Promise<BundleStatusSnapshot>;
};
```

This is enough to support same-chain relay submission, quote-driven flows, and
future provider swaps.

But the minimal shape does **not** mean loose semantics.
An adapter is only correct if it satisfies all of the following:

1. `prepare` returns a verifiable commitment package
2. `execute` executes the prepared package, not a reinterpretation of it
3. provider and transport failures map to stable SDK-visible error codes
4. `getStatus` returns a monotonic view of bundle progress and terminality

The contract is language-neutral. The real backend may be written in Go,
TypeScript, or anything else. What must remain consistent is the commitment
schema, digest semantics, and wire behavior.

## What this module does not assume

This module does **not** assume:

- one provider
- one backend language
- one execution payload format
- one sponsorship model
- one onchain verification contract

That last point matters most.
The relay verification model is not “Calibur verification.” It is a pre-sign
backend-commitment check that can still make sense when the user's signed
payload is not a Calibur direct batch.

## How to read the module

For a first pass:

1. `transport.ts`
2. `fallbackPolicy.ts`
3. `statusReducer.ts`
4. `executionFlow.ts`
5. `lifecycle.ts`
6. `responseDigest.ts`
7. `prepareValidation.ts`

Then read `src/actions/internal/preflightRelay.ts` and
`src/actions/internal/relayExecution.ts` to see how the module is integrated
into `execute.relay(...)`.

For the deeper protocol semantics, continue to:

- `src/relay/intent-model/README.md`
- `verification-model.md`

## The design test

A good question to ask of any proposed change is:

> **Does this make transport easier by weakening correctness, or does it make correctness clearer without changing what the system guarantees?**

Only the second kind of change belongs here.
