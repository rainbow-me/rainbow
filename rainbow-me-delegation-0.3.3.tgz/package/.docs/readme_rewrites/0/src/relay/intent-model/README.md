# Relay Intent Model

This document defines the object the relay path proves before execution.

If `src/relay/README.md` explains **what the relay module owns**, this document
explains **what the relay module is actually proving**.

The shortest correct summary is:

> **Relay execution only proceeds when the SDK can prove that the backend's prepared commitment matches the request the client is about to authorize.**

That statement is more precise than “the client validates the transaction.”
The relay path is not only about the transaction payload. It is about the
backend commitment around that payload.

## The mistake this model avoids

The easiest way to misunderstand relay verification is to conflate these two
things:

1. **the transaction payload** — the calls or transaction the user signs
2. **the execution commitment** — what the backend has agreed to do with that
   payload, under what terms, under what relay domain, and with what
   sponsorship arrangement

Those are not the same object.

In some execution models, the client controls almost all of the payload.
In others, backend- or provider-sourced values enter the payload directly.
But in every relay model, the backend contributes execution terms that the
client cannot derive independently.

That is why `Prepare` exists.
If `Prepare` were merely advice, local simulation or direct execution would be
enough. `Prepare` exists because the backend is introducing terms the client
must learn from the network — and therefore must be able to verify.

## Core rule

The core rule implemented by this SDK is:

> For a relay execution to proceed, the SDK must be able to verify that the
> prepared package is a signed backend commitment to the same request, the same
> call sequence, the same execution context, and the same quote/domain context
> that the client is about to act on.

Everything else in this document is the machinery required to make that
statement true.

## The two sides of the protocol

### Client-local side

The client knows, or can derive locally:

- `chainId`
- `account`
- `calls`
- `value`
- delegation decision and delegated contract
- `policyBindingHash`
- `runtimeBindingHash`
- `nonceLane`
- `clientRequestId`
- required trust guards:
  - expected quote signer
  - expected chain-set hash
  - optional required sponsorship mode

These are the values the SDK is allowed to treat as local truth.

### Backend-supplied side

The backend supplies, either directly or via a provider quote:

- relay domain metadata
- quote identifier and validity window
- fee terms
- sponsorship flag
- fee-derivation metadata
- provider-specific execution context that later becomes a relay submission or a
  quote-driven action

These are the values that must be cryptographically bound to the client-local
request before relay execution is allowed.

## The prepared package

A prepared relay package contains four conceptual parts.

### 1. Relay domain (`QuoteDomain`)

This answers: **who issued the quote, and where is it valid?**

Fields:

- `relayId`
- `relayVersion`
- `environment`
- `chainSetHash`
- `quoteSigner`

### 2. Quote payload (`QuotePayload`)

This answers: **what terms were quoted?**

Fields:

- `quoteId`
- `issuedAt`
- `expiresAt`
- `maxClockSkewSec`
- `feeToken`
- `feePayer`
- `maxFee`
- `feeDerivationHash`
- `sponsored`

### 3. Response binding (`PrepareResponseBinding`)

This answers: **what exact commitment did the backend sign?**

Fields:

- `quoteDigest`
- `executionDigest`
- `callsHash`
- `clientRequestId`

### 4. Response signature (`responseSignature`)

This is the backend's signature over the binding.

In the current design, the signature envelope is EIP-712 typed data:

- **domain:** `RainbowRelayPrepare`
- **version:** `1`
- **message:** `PrepareResponseBinding`

The outer EIP-712 envelope is not the protocol itself. It is the attestation
format for the protocol's binding object.

## Why the binding has four fields

The response binding signs four fields because each closes a different part of
the continuity problem.

### `callsHash`

This is the stable commitment to ordered call tuples.

It is the simplest answer to:

> “Is the prepared package talking about the same call sequence the client is
> about to execute?”

### `executionDigest`

This binds the execution-authorization surface.

It covers:

- chain ID
- account
- delegation decision
- delegation contract
- nonce lane
- total value
- call tuples
- policy binding hash
- runtime binding hash
- fee token
- fee payer
- max fee
- client request ID

This is the digest of **what will execute, for whom, and under what economic
terms**.

### `quoteDigest`

This binds the relay-commitment surface.

It covers:

- relay identity
- relay version
- environment
- chain-set context
- quote signer
- intent bindings
- quote terms

This is the digest of **what the relay/backend committed to as quote and domain
context**.

### `clientRequestId`

This binds request identity continuity.

It answers:

> “Is this commitment for the request the client actually made, or for some
> other request with similar calls?”

## Why the digest set is split

A tempting alternative would be one giant hash over everything.
That would detect mismatch, but it would collapse two different commitments into
one opaque blob.

The SDK keeps the split because the commitments have different owners and
lifecycles.

### `executionDigest` exists because execution authorization is its own object

The execution surface is about:

- account
- chain
- calls
- fees
- delegation state
- request identity

That is the object the client is authorizing.

### `quoteDigest` exists because relay/domain context is its own object

The quote surface is about:

- who is speaking (`quoteSigner`, relay identity)
- where the quote is valid (`chainSetHash`, environment)
- what economic terms are being proposed
- what intent bindings those terms attach to

That is the object the backend is committing to.

### `callsHash` remains explicit because call continuity matters directly

Call continuity is important enough to stay legible.
A direct stable commitment over ordered call tuples is useful both for local
parity checks and for execute-time continuity reasoning.

This split is what lets the SDK catch domain-level mutation that does not alter
call tuples. That is why a chain-context tamper can leave `executionDigest`
unchanged and still be a protocol failure.

## `hashCalls(...)` and `hashIntent(...)`

The SDK maintains two related but distinct intent views.

### `hashCalls(...)`

`hashCalls(...)` hashes the ordered call tuples only.

Current relay preflight uses this directly because call-sequence continuity is a
first-class requirement and because the binding already carries an explicit
`executionDigest` for the wider envelope.

### `hashIntent(...)`

`hashIntent(...)` hashes the full execution intent envelope.

It is still important because it provides the full execution-authorization
surface used to derive `expectedExecutionDigest` locally.

Put differently:

- `callsHash` is the compact stable answer to “same calls?”
- `executionDigest` is the compact stable answer to “same execution envelope?”

Both matter.

## Validation order

The order of validation is not arbitrary.
It reflects the protocol's trust boundary.

### Stage 1: trust guards in `preflightRelay(...)`

Before digest verification, the SDK applies the trust guards that the caller
pins when starting relay execution.

Checks:

1. prepared `quoteSigner` must equal expected quote signer
2. prepared `chainSetHash` must equal expected chain-set hash
3. if sponsorship mode was required, prepared `sponsored` must match it

These checks answer:

> “Is this prepared object even about my request?”

If the answer is no, the SDK throws an integrity failure before deeper digest
work is even relevant.

### Stage 2: `validatePreparedQuote(...)`

Once trust guards pass, the SDK validates the prepared commitment in a fixed
order.

1. **quote-time acceptance**
   - `issuedAt`, `expiresAt`, `maxClockSkewSec`
2. **fee-derivation integrity**
   - `hashFeeDerivation(feeDerivation)` must equal
     `quotePayload.feeDerivationHash`
3. **derived max-fee equivalence**
   - derived `maxFee` must equal `quotePayload.maxFee`
4. **fee policy bounds**
   - adjustment and absolute-cap checks
5. **quote digest equivalence**
   - recompute from expected relay domain, intent bindings, and quote payload
6. **calls-hash equivalence**
   - recompute from local calls
7. **execution-digest equivalence**
   - recompute from local execution context and prepared fee terms
8. **client-request-id equivalence**
9. **signature authenticity**
   - recover signer from the EIP-712 binding signature and require it to match
     the expected quote signer

Only after all of that is relay execution allowed.

## What this proves

When validation passes, the SDK has proved all of the following.

### 1. Request continuity

The prepared package is for the same request the client made, not merely for a
similar one.

### 2. Call continuity

The prepared package is bound to the same ordered call tuples the client is
using locally.

### 3. Execution-envelope continuity

The prepared package is bound to the same chain/account/delegation/fee/request
context the client is about to authorize.

### 4. Quote/domain continuity

The prepared package is bound to the expected relay signer and quote/domain
context.

### 5. Time validity

The quote is still acceptable under local clock semantics.

### 6. Fee arithmetic integrity

The declared fee derivation produces the fee terms that were signed into the
quote commitment.

### 7. Source authenticity

The binding was signed by the expected backend quote signer.

This is the client-side trust boundary for relay execution.

## What this does not prove

The model is strong, but it is not magic.

It does **not** prove:

- that the quoted terms are economically optimal
- that the backend chose those terms honestly at quote-construction time
- that a compromised quote signer cannot produce bad but internally consistent
  commitments
- that a provider will certainly perform well economically or operationally

What it does prove is narrower and more important:

> the client is not acting on unbound backend state.

That is the difference between “the backend suggested some terms” and “the
backend cryptographically committed to these terms, for this request, and the
SDK verified that before proceeding.”

## Failure mapping

Validation failures map to a small set of relay-visible failure codes.

- quote-time invalid:
  - `NEAR_EXPIRY` → `QUOTE_EXPIRED`
  - other quote-time failures → `INVALID_BINDING`
- invalid response signature → `INVALID_SIGNATURE`
- any other binding mismatch → `INVALID_BINDING`

Those codes then flow into class-based fallback policy.

This is important because relay correctness is not just “detect mismatch.” It is
also “react to mismatch predictably.”

## Fallback semantics

Current fallback behavior follows one principle:

> **Never automatically degrade the user's semantics just because relay failed.**

That leads to the current rules:

- integrity failures do not auto-fallback
- quote expiry may trigger one bounded reprepare
- transport failures may direct-fallback only when sponsorship semantics are
  preserved
- sponsored quotes fail closed rather than silently becoming user-paid direct
  transactions

This is why fallback belongs inside the same model as verification.
If you split them apart, you lose the ability to say what the system actually
guarantees.

## Execution models covered by the same proof

The relay intent model is deliberately more general than one payload shape.

### Same-chain, full sponsorship

The user signs client-originated application calls.
The backend contributes fee and sponsorship terms that influence execution but do
not necessarily enter the signed batch directly.

The model still applies because the backend commitment is about more than the
payload alone.

### Same-chain, user pays in token

The user signs application calls plus a gas-payment call that uses backend
terms such as `feeToken`, `feePayer`, and `maxFee`.

Here the backend terms enter the signed payload directly.
The same commitment model still applies.

### Cross-chain, quote-driven intent

The provider quote may determine the origin-chain deposit target, value, and
routing calldata the user signs, while the destination action is executed later
by the provider or solver.

The same commitment model still applies because the question remains the same:

> “Has the backend committed to execution terms consistent with my intent?”

That question is about commitment integrity, not about one specific payload
shape.

## Relationship to Calibur

Calibur and relay pre-sign verification are complementary.
They are not substitutes.

### Calibur

Calibur is the onchain authority and policy boundary.
It makes invalid execution revert even if everything offchain fails.

### Relay verification

Relay verification is the pre-sign commitment boundary.
It prevents the client from acting on unverified backend terms before onchain
execution is even attempted.

The relay model should therefore not be coupled to “7702-only” thinking.
Calibur requires delegated execution. Relay commitment verification does not.
It is a more general client-side correctness primitive.

## Implementation map

The intent model lives across these files:

- `src/relay/intentHash.ts`
- `src/relay/quoteDigest.ts`
- `src/relay/responseDigest.ts`
- `src/relay/quoteTime.ts`
- `src/relay/feeDerivation.ts`
- `src/relay/prepareValidation.ts`
- `src/actions/internal/preflightRelay.ts`
- `src/actions/internal/relayExecution.ts`
- `src/relay/fallbackPolicy.ts`

Read them in roughly that order if you want to move from pure protocol semantics
to orchestration.

## The design question to keep asking

When reviewing a relay change, ask this:

> **What new field or behavior is now capable of influencing execution, and where is that influence cryptographically bound and locally verified?**

If the answer is vague, the model is incomplete.
If the answer is explicit, the relay path is still coherent.
