# Rainbow Wallet SDK

Rainbow's transaction and account-runtime SDK.

This SDK is the execution surface that sits between the wallet account, the
runtime layers that may participate in execution, and the offchain services
that help route, sponsor, and submit transactions. It is not only about
delegation. It is where three things meet:

1. **Account control** — who is allowed to act.
2. **Policy enforcement** — what those actors are allowed to do.
3. **Execution correctness** — how calls are prepared, signed, submitted, and,
   when relay infrastructure is involved, verified before the user commits.

At the public API boundary, the API is intentionally small:

- `configure` — one setup boundary for required platform services
- `delegation`, `authority`, `policy`, `factor`, `recovery`, `execute` — six
  namespaces that own the runtime and execution model
- `useDelegations`, `useDelegationDisabled`, `useWillDelegate` — three React
  hooks built on the same underlying state model

That small API surface hides a deliberate architecture: the SDK normalizes
client inputs, resolves delegation state, checks policy locally before
execution, and treats backend relay responses as adversarial input unless they
can be cryptographically verified.

## Installation

Install the SDK together with its required peer dependencies:

- `viem@^2.38.0`
- `@storesjs/stores@^0.8.6`

Optional peer dependencies:

- `react` — required only when using the hooks
- `ethers` — required only when passing ethers client inputs

## What this SDK is for

This SDK is built for a wallet that wants account control, policy, and
execution to feel like one coherent transaction surface without giving up
correctness.

That means it must support all of the following at once:

- preparing and executing batched calls against the wallet account
- managing authority keys and policy state on the runtime layer when one is in
  use
- supporting different signing factors without changing execution semantics
- routing execution through a relay backend when sponsorship, provider
  submission, or quote-driven execution is desired
- preserving one coherent model of what a transaction means, regardless of
  whether it executes directly or through a relay

The architecture is shaped by one rule:

> **Execution mode may change. Correctness guarantees may not.**

Direct execution, signed execution, and relay-backed execution are all different
ways to reach the chain. They should not each invent their own trust model,
status model, or fallback behavior.

## The mental model

There are three distinct layers in this system.

### 1. Account runtime

The runtime layer, including Calibur where delegated execution is in use, is
the hard onchain boundary.
It enforces who can act and what they can do.

This is where key roles, spend limits, fee limits, call permissions, and
session-key constraints ultimately become authoritative.

### 2. SDK execution layer

The SDK is the pre-sign and pre-submit correctness layer.
It decides what should be signed, whether execution is permitted, and whether a
relay response is consistent with the request the client actually made.

This is where direct execution and relay execution are kept behaviorally
coherent.

### 3. Transport and backend layer

Backends and providers help with quoting, sponsorship, submission, and status.
They may be economically important, but they are not supposed to become a new
trusted source of truth merely because they sit on the network path.

That distinction matters most in relay flows. A `Prepare` response is not just
metadata. It is a backend commitment that the SDK verifies before execution
proceeds.

## Public API

The root export surface is:

- `configure`
- `authority`, `delegation`, `execute`, `factor`, `policy`, `recovery`
- `useDelegations`, `useDelegationDisabled`, `useWillDelegate`
- `Services`, `ActiveDelegations`, `DelegationWithChainId`

The shape is intentionally namespace-driven rather than function-sprawl. Each
namespace owns one piece of the model.

### `configure(...)`

Before using bound namespace methods, the SDK must be configured with the
platform services it relies on:

- `platformClient`
- `logger`
- `getCurrentAddress`

Optionally:

- `storeOptions`
- `readAccountCode`
- `resolveDelegationCapability`

The context layer is documented in `src/context/README.md`.
It is where dependency injection, viem/ethers normalization, and runtime
service validation happen.

### `delegation`

`delegation` owns support checks, current status, delegation execution, revoke
execution, and store-backed enable/disable state.

Top-level exports:

- `isSupported`, `willDelegate`, `active`, `shouldRevoke`
- `delegate`, `revoke`
- `enable`, `disable`, `isEnabled`

Use it when you need to answer questions like:

- does this chain/account support delegation?
- will this account delegate if I try to execute?
- what is the current delegation state?
- should an existing delegation be revoked?

### `authority`

`authority` owns the lifecycle of control keys and authority roots.

Top-level exports:

- `hashControlKey`
- `register`, `rotate`, `revoke`
- `addAuthorityRoot`, `removeAuthorityRoot`, `update`
- `forAccount`

This namespace is about **who** is allowed to administer or act through the
runtime. The `forAccount(...)` surface returns runtime-aware key and governance
readers.

### `policy`

`policy` owns the read and write surface for execution constraints.

Top-level exports:

- `apply`
- `setCallRule`, `setSpendLimit`, `setFeeLimit`, `setNonceLaneRule`
- `forAccount`

This namespace is about **what** an actor is allowed to do. The
`forAccount(...)` surface returns runtime-aware rule and usage readers.

When execution should be policy-checked, callers pass
`policyContext: { policy, principalId }` to the execution entrypoint.

### `factor`

`factor` owns signing-factor abstraction and onboarding helpers.

Top-level exports:

- `passkey`, `externalWallet`, `custom`, `resolve`
- `onboarding.preferredType`, `onboarding.select`
- `onboarding.hasAlternative`, `onboarding.baselines`,
  `onboarding.baseline`

It lets the SDK remain factor-neutral: external wallet, passkey, or custom
factor selection can change the signing strategy without changing the
underlying execution model.

### `recovery`

`recovery` owns protocol-root governance recovery actions and status.

Top-level exports:

- `disableProtocolRoot`, `enableProtocolRoot`
- `request`, `execute`, `cancel`
- `status`

This namespace is intentionally narrow. It exists because recovery controls are
a first-class part of operating accounts safely.

### `execute`

`execute` is the transaction surface.

Top-level exports:

- `prepare` — build a transaction object for simulation / gas estimation
- `batch` — execute batched calls directly against the account
- `signedBatch` — execute batched calls through a signed-execute envelope
- `relay` — execute through a relay transport with deterministic fallback

This is the namespace most readers should understand first, because it is where
delegation, policy, runtime capability, and relay semantics meet.

## Hooks

The SDK also exports three React hooks:

- `useDelegations`
- `useDelegationDisabled`
- `useWillDelegate`

These require `react` as an optional peer dependency.

## Two direct execution paths

The SDK exposes two direct execution modes.

### `execute.batch(...)`

This is the standard batch-execution path.
The SDK resolves delegation state internally and either:

- executes directly if the account is already delegated, or
- performs delegation + execution when delegation is required and supported.

If `policyContext` is provided, the SDK preflights policy before execution.

### `execute.signedBatch(...)`

This is the factor-neutral signed-execute path.
The caller supplies signing strategy through `signedExecute.signDigest`, and the
SDK builds the deterministic signed-execute envelope from runtime capability and
execution context.

The important design point is that the factor changes, but the execution model
does not.

## Relay execution in one paragraph

`execute.relay(...)` is not a thin wrapper over backend endpoints.

It is a full correctness pipeline:

1. resolve delegation state
2. optionally preflight policy
3. call `transport.prepare(...)`
4. verify the prepared relay commitment against local intent before relay
   execution is allowed
5. call `transport.execute(...)`
6. poll `transport.getStatus(...)`
7. apply deterministic fallback policy when relay fails
8. reduce relay and direct legs into one unified status model

The relay backend is therefore a **transport adapter**, not the owner of
correctness.

For the deeper model, read:

- `src/relay/README.md`
- `src/relay/intent-model/README.md`
- `verification-model.md`

## Why relay is designed this way

The relay path exists because some execution terms cannot be derived locally:
provider pricing, sponsorship eligibility, fee derivation, quote validity, and,
in some execution models, the payload the user will sign.

That creates a new trust boundary.

The SDK solves it by treating the backend `Prepare` response as a signed
commitment, not as advisory JSON. The prepare binding is signed as EIP-712 typed
data (`RainbowRelayPrepare`, version `1`) and verified against client-local
intent before relay execution proceeds. That is what turns relay execution from
"backend-assisted" into "client-verifiable."

The point is not to prove the backend chose economically optimal terms. The
point is to prove that the terms being acted on are the ones the backend
committed to, and that they match the request the client actually made.

## Example: direct batch execution

Examples below focus on call shape and execution flow rather than package-
specific import paths.

```ts
configure({
  platformClient,
  logger,
  getCurrentAddress,
});

const result = await execute.batch({
  walletClient,
  publicClient,
  chainId,
  calls: [
    {
      to: tokenAddress,
      value: 0n,
      data: approveCalldata,
    },
    {
      to: routerAddress,
      value: 0n,
      data: swapCalldata,
    },
  ],
  transactionOptions,
  nonce,
});
```

What happens under the hood:

1. the SDK checks delegation support and current runtime state
2. it chooses direct execution vs delegation + execution
3. if `policyContext` is present, it verifies policy compatibility first
4. it submits one coherent transaction path

## Example: relay execution

```ts
const result = await execute.relay({
  walletClient,
  publicClient,
  chainId,
  calls,
  transactionOptions,
  nonce,
  relay: {
    transport,
    clientRequestId,
    expectedQuoteSigner,
    expectedChainSetHash,
    expectedSponsored: true,
  },
});
```

The relay transport is minimal by design:

```ts
type Transport<TPrepared> = {
  prepare: (context: { chainId: number }) => Promise<TPrepared>;
  execute: (prepared: TPrepared) => Promise<{ bundleId: string }>;
  getStatus: (bundleId: string) => Promise<BundleStatusSnapshot>;
};
```

This keeps provider-specific HTTP contracts out of the SDK while keeping relay
behavior deterministic inside the SDK.

## Status model

The SDK reduces relay and direct outcomes into one status contract.

Unified status values:

- `SUBMITTING`
- `PENDING`
- `CONFIRMED_RELAY`
- `CONFIRMED_DIRECT`
- `FAILED`

Execution-path values:

- `relay`
- `direct`
- `hybrid`

This means callers do not need to invent their own precedence rules for cases
like “relay failed, direct succeeded” or “relay is still pending but status
transport is unhealthy.”

## Design principles

### One execution model, multiple paths

Direct and relay execution are different transports for execution intent. They
should not produce different meanings for policy, sponsorship safety, or status.

### Treat relay responses as adversarial input

If a backend response affects what executes or what the user pays, it must be
verifiable before the SDK proceeds.

### Onchain policy is the hard boundary

The runtime contract is the final authority. Offchain components may prepare,
price, or route. They do not decide what is allowed.

### Factor-neutral signing

Changing the signing factor should not require rewriting the transaction model.

### Provider-specific code belongs at the edge

The SDK owns correctness. Adapters own HTTP and provider-shape translation.

## Repository guide

If you are new to the codebase, read in this order:

1. `src/context/README.md` — how configuration and client normalization work
2. `src/api/execute.ts` — the public execution namespace
3. `src/actions/executeBatchedTransaction.ts` — direct execution
4. `src/actions/executeRelayBatchedTransaction.ts` — relay entrypoint
5. `src/relay/README.md` — relay module architecture
6. `src/relay/intent-model/README.md` — what the relay path actually proves
7. `verification-model.md` — the full first-principles argument for why relay
   `Prepare` must be a signed commitment

## What this SDK is not

This SDK is not:

- a provider-specific relay client
- a backend quote engine
- a generic wallet adapter zoo
- an ad hoc collection of transaction helpers

It is a correctness-oriented execution SDK for Rainbow.
That distinction is what keeps the design coherent.
