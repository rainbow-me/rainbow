# Relay Architecture

`src/relay` is the SDK's relay correctness core.

Its job is narrow and strict:

> Given a prepared relay package and a possible direct fallback path, produce
> one deterministic execution decision and one deterministic status outcome.

This module is protocol logic, not transport glue.

## Why this module exists

Direct execution has one trust boundary: the client and the chain.

Relay execution introduces an additional boundary: backend `prepare` output.
That creates two failure modes if left unmodeled:

1. trust drift: client signs against mismatched or tampered prepared data
2. fallback drift: each caller/provider invents its own retry and fallback
   behavior

`src/relay` exists to make both impossible under normal integration.

## Core invariants

These are non-negotiable module guarantees.

- Integrity failures do not auto-fallback.
- Sponsorship semantics are preserved during fallback.
- Fallback is class-based and deterministic.
- Relay and direct legs reduce to one status contract.
- Transport adapters are replaceable; integrity semantics are not.

If a change weakens any invariant above, treat it as a regression.

## Ownership boundaries

This module owns:

- relay intent and binding hash logic
- prepare-response signature and digest verification
- quote-time acceptance
- failure classification and fallback policy
- lifecycle orchestration across `prepare` / `execute` / `getStatus`
- unified status reduction
- idempotency and circuit-breaker helper primitives

This module does not own:

- provider-specific HTTP contracts
- backend quote generation and pricing policy
- delegation capability resolution
- onchain authority/policy enforcement
- application-level retry UX or metric persistence

Boundary rule: adapters map provider contracts into SDK transport shape; relay
module decides if execution is allowed and how outcomes are interpreted.

## Integration boundary in SDK

Public entrypoint: `execute.relay(...)`.

Primary owners in the action layer:

- `src/actions/executeRelayBatchedTransaction.ts`
- `src/actions/internal/preflightRelay.ts`
- `src/actions/internal/relayExecution.ts`

Execution order:

1. resolve delegation decision
2. optional policy preflight
3. call transport `prepare`
4. verify prepared commitment against local intent
5. call transport `execute`
6. poll transport `getStatus`
7. apply deterministic fallback policy if needed
8. reduce to unified execution status

The direct fallback leg reuses the same direct execution owners as
`execute.batch(...)`.

## Commitment model

`prepare` returns `RelayInput` with a signed commitment envelope.

At a high level, commitment contains:

- relay domain (`relayId`, `relayVersion`, `environment`, `chainSetHash`)
- quote payload (`quoteId`, validity window, sponsorship, fee metadata)
- response binding (`quoteDigest`, `executionDigest`, `callsHash`,
  `clientRequestId`)
- response signature by expected quote signer
- fee derivation metadata used for local arithmetic checks

Typed-data envelope for response binding:

- EIP-712 domain name: `RainbowRelayPrepare`
- EIP-712 domain version: `1`

The envelope format is transport. The security semantics come from local digest
recomputation and ordered validation.

## Validation stages

`preflightRelay(...)` applies validation in two stages.

### Stage 1: trust guards

Caller pins guard fields before expensive validation:

- `expectedQuoteSigner`
- `expectedChainSetHash`
- optional sponsorship requirement

This stage rejects obviously wrong domain context early.

### Stage 2: prepared quote validation

`validatePreparedQuote(...)` runs ordered checks:

1. quote time acceptance
2. fee-derivation hash equivalence
3. derived max-fee equivalence and policy bounds
4. quote digest equivalence
5. calls hash equivalence
6. execution digest equivalence
7. client request id equivalence
8. signature authenticity and signer match

Relay execute cannot proceed unless all checks pass.

## Fallback policy

`fallbackPolicy.ts` maps failure classes to deterministic decisions.

Current policy shape:

- integrity failure: fail closed, no auto-fallback
- quote-expired failure: bounded reprepare path, then guarded fallback
- transport failure: guarded fallback
- sponsorship-required failure: fail closed
- unknown failure: fail closed

Guarded fallback requires semantic safety checks such as sponsorship
preservation and direct execution support.

## Unified status model

`statusReducer.ts` and `executionFlow.ts` reduce outcomes into one contract:

- `SUBMITTING`
- `PENDING`
- `CONFIRMED_RELAY`
- `CONFIRMED_DIRECT`
- `FAILED`

with provenance:

- `executionPath`: `relay` | `direct` | `hybrid`
- relay bundle id (if present)
- direct tx hash (if present)
- per-leg failure metadata

Goal: callers never invent their own relay/direct precedence rules.

## Transport contract

```ts
type Transport<TPrepared> = {
  prepare: (context: { chainId: number }) => Promise<TPrepared>;
  execute: (prepared: TPrepared) => Promise<BundleReceipt>;
  getStatus: (bundleId: BundleId) => Promise<BundleStatusSnapshot>;
};
```

Adapter obligations:

1. `prepare` must return enough signed material for SDK integrity validation.
2. `execute` must execute the prepared package, not reinterpret it.
3. `getStatus` must produce monotonic terminal transitions.
4. provider errors must map cleanly to fallback classes.

## Digest responsibility split

Digest separation is intentional:

- `callsHash`: binds call sequence and payload
- `executionDigest`: binds execution envelope (chain/account/delegation/fee
  context/client request)
- `quoteDigest`: binds relay domain + quote payload + execution context

This separation keeps ownership explicit and prevents one digest from becoming
an opaque bucket for unrelated semantics.

## Operational helpers

- `idempotency.ts`: deterministic logical intent and attempt IDs
- `circuitBreaker.ts`: pure threshold evaluation for relay quarantine signals

These are pure helpers. Persistence and traffic-routing actions are owned by
caller infrastructure.

## File map

- `intentHash.ts`
- `quoteDigest.ts`
- `responseDigest.ts`
- `quoteTime.ts`
- `prepareValidation.ts`
- `fallbackPolicy.ts`
- `lifecycle.ts`
- `executionFlow.ts`
- `statusReducer.ts`
- `transport.ts`
- `idempotency.ts`
- `circuitBreaker.ts`
