# Relay Intent Model

This document defines the object the SDK proves before relay execution is
allowed.

If `src/relay/README.md` explains module ownership, this file explains the
actual proof contract.

## Core claim

Relay execution proceeds only if the SDK can verify that prepared relay data is
a signed backend commitment to the same request the client is about to execute.

"Same request" means continuity across:

- call sequence
- execution envelope
- quote/domain context
- request identity

If continuity fails, relay execution is denied.

## Why this exists

Relay introduces backend-originated values the client cannot derive from chain
state alone: quote terms, sponsorship flags, domain metadata, and fee
parameters.

Without a commitment model, those values become trusted by default.

The intent model prevents that by requiring local recomputation of expected
bindings and signer validation before any relay execute call.

## Model objects

### 1. Local execution context

Client-known or client-derived inputs:

- `chainId`
- `account`
- `calls`
- `value`
- delegation decision + delegation contract
- `policyBindingHash`
- `runtimeBindingHash`
- `nonceLane`
- `clientRequestId`
- trust guards:
  - expected quote signer
  - expected chain set hash
  - optional sponsorship requirement

These values are local truth for verification.

### 2. Prepared relay package

Network-provided commitment package:

- `quoteDomain`
- `quotePayload`
- `responseBinding`
- `responseSignature`
- `feeDerivation`

This package is accepted only if it passes the verification algorithm below.

## Binding structure

`responseBinding` carries four fields:

- `quoteDigest`
- `executionDigest`
- `callsHash`
- `clientRequestId`

Each field closes a different continuity edge.

- `callsHash`: same ordered call tuples
- `executionDigest`: same execution envelope (chain/account/delegation/fees/
  bindings/request id)
- `quoteDigest`: same quote + relay domain context
- `clientRequestId`: same logical request identity

## Digest responsibilities

Digest split is intentional.

- `callsHash` is the direct parity check for call tuples.
- `executionDigest` is parity for execution-authorized context.
- `quoteDigest` is parity for backend quote/domain commitment.

One giant hash could detect mismatch but would collapse ownership boundaries into
an opaque value.

## Signature model

Prepared response binding is signed as EIP-712 typed data:

- domain name: `RainbowRelayPrepare`
- domain version: `1`
- message: `PrepareResponseBinding`

Recovered signer must equal expected quote signer from trust guards/domain
expectation.

## Verification algorithm

Verification runs in two stages.

### Stage A: trust guard checks

Before digest verification:

1. prepared `quoteSigner` must equal expected quote signer
2. prepared `chainSetHash` must equal expected chain set hash
3. if sponsorship is required, prepared `sponsored` must match requirement

If any fails, package is rejected immediately.

### Stage B: prepared commitment checks

`validatePreparedQuote(...)` applies ordered checks:

1. quote-time acceptance (`issuedAt`, `expiresAt`, `maxClockSkewSec`)
2. `hashFeeDerivation(feeDerivation) == quotePayload.feeDerivationHash`
3. derived `maxFee == quotePayload.maxFee`
4. policy bounds on fee derivation
5. recomputed `quoteDigest == responseBinding.quoteDigest`
6. recomputed `callsHash == responseBinding.callsHash`
7. recomputed `executionDigest == responseBinding.executionDigest`
8. expected `clientRequestId == responseBinding.clientRequestId`
9. recovered signer from `responseSignature` equals expected quote signer

Relay execute is permitted only when all checks succeed.

## Failure normalization

Preflight normalization maps failures into stable classes.

- quote time near expiry -> `QUOTE_EXPIRED`
- quote time other invalid reason -> `INVALID_BINDING`
- invalid response signature -> `INVALID_SIGNATURE`
- any digest/request mismatch -> `INVALID_BINDING`

These normalized classes are consumed by fallback policy.

## Fallback interaction

Intent verification is upstream of fallback.

- integrity-class failures do not auto-fallback
- quote-expiry class may allow bounded reprepare path
- direct fallback is gated by sponsorship-preservation and direct support checks

This prevents a mismatch in trust boundary from being treated as ordinary
transport instability.

## What this model proves

If verification passes, SDK has proved:

- backend signed the binding object
- signer matches expected relay quote signer
- quote/domain context matches expected guardrails
- call tuples match local request
- execution envelope matches local expectation
- request identity matches client request id

## What this model does not prove

This model does not prove:

- quote economic optimality
- backend liveness
- provider fill quality
- app-level retry policy correctness

Those concerns are real but outside this proof boundary.

## Execution-path integration

In `execute.relay(...)`, this model is applied before relay execute.

High-level order:

1. resolve delegation decision
2. build local expected bindings
3. call `transport.prepare(...)`
4. run trust guards + commitment validation
5. if valid, call relay execute path
6. if invalid, map to typed preflight/fallback behavior

This ordering is mandatory. Validation after execute is too late.
