# Rainbow Wallet SDK

Rainbow's transaction and account-runtime SDK.

This README is structured around the real exported API surface. Each namespace
section is a standalone glossary for that domain: what it owns, what it
contains, and what guarantees/constraints matter in practice.

## Installation

```bash
yarn add viem@^2.38.0 @storesjs/stores@^0.8.6
```

Optional peer dependencies:

- `react` for hooks
- `ethers` for ethers client inputs

## Configure Once

Call `configure(...)` before any namespace method or hook usage.

```ts
configure({
  platformClient,
  logger,
  getCurrentAddress,
  // optional
  storeOptions,
  readAccountCode,
  resolveDelegationCapability,
});
```

Required services:

- `platformClient`
- `logger`
- `getCurrentAddress`

Optional services:

- `storeOptions`
- `readAccountCode`
- `resolveDelegationCapability`

## Root Exports (Exact)

From `src/index.ts`, the package exports:

- `configure`
- `authority`
- `delegation`
- `execute`
- `factor`
- `policy`
- `recovery`

Hooks:

- `useDelegationDisabled`
- `useDelegations`
- `useWillDelegate`

Types:

- `Services`
- `ActiveDelegations`
- `DelegationWithChainId`

## Client Input Model

Transaction methods accept either client shape:

- viem: `{ walletClient, publicClient, ... }`
- ethers: `{ signer, provider, chainId, ... }`

The SDK normalizes both shapes to viem clients internally.

## `delegation` Namespace

### Domain

Delegation state and lifecycle for batched execution, plus local user gating for
whether delegation should be used.

### Contains

| Member                                                                                           | Kind             | Contract                                                                                          |
| ------------------------------------------------------------------------------------------------ | ---------------- | ------------------------------------------------------------------------------------------------- |
| `isSupported({ address, chainId, readCode?, requireFreshStatus? })`                              | Read             | Returns `{ supported, reason }`. `reason` is `USER_DISABLED`, `NOT_AVAILABLE`, or `null`.         |
| `willDelegate({ address, chainId, readCode?, requireFreshStatus? })`                             | Read             | Returns whether the next batched send would authorize delegation: `{ willDelegate, delegation }`. |
| `active({ address })`                                                                            | Read             | Returns active delegations across chains.                                                         |
| `shouldRevoke({ address })`                                                                      | Read             | Returns `{ shouldRevoke, revokes }` with chain/address revoke targets.                            |
| `delegate({ chainId, calldata, value?, transactionOptions, nonce, policyContext?, ...clients })` | Execute          | Performs explicit delegation + calldata execution after fresh preflight.                          |
| `revoke({ chainId, transactionOptions, nonce, ...clients })`                                     | Execute          | Revokes delegation by signing zero-address authorization and executing account self-call.         |
| `enable(address)`                                                                                | Local state      | Enables delegation usage for an address in local store state.                                     |
| `disable(address)`                                                                               | Local state      | Disables delegation usage for an address in local store state.                                    |
| `isEnabled(address)`                                                                             | Local state read | Returns local delegation-enabled flag.                                                            |

### Behavioral Guarantees

- `isSupported` and `willDelegate` can use `readCode`/configured
  `readAccountCode` to correct stale backend delegation state with onchain code
  truth.
- `delegate` always performs fresh delegation/runtime preflight before send.
- `revoke` is treated as cleanup and is allowed regardless of local
  enable/disable preference.
- `enable`/`disable` are not onchain writes.

## `execute` Namespace

### Domain

Primary transaction send surface. Owns planning and execution across direct,
signed, and relay paths.

### Contains

| Member                                                                                                                              | Kind     | Contract                                                                                       |
| ----------------------------------------------------------------------------------------------------------------------------------- | -------- | ---------------------------------------------------------------------------------------------- |
| `prepare({ from, calls, chainId, nonce, readCode? })`                                                                               | Planning | Returns simulation transaction shape `{ from, to, data, value, authorization_list? }`.         |
| `batch({ chainId, calls, value?, transactionOptions, nonce, policyContext?, ...clients })`                                          | Execute  | Standard batched path. Chooses direct vs authorize+execute from preflight delegation decision. |
| `signedBatch({ chainId, calls, value?, transactionOptions, nonce, signedExecute, policyContext?, ...clients })`                     | Execute  | Signed-execute envelope path using caller-provided digest signer in `signedExecute`.           |
| `relay({ chainId, calls, value?, transactionOptions, nonce, relay, directExecution?, signedExecute?, policyContext?, ...clients })` | Execute  | Relay transport lifecycle with deterministic direct fallback behavior.                         |

### Relay Config Contract

`execute.relay` takes a `relay` adapter object containing transport callbacks
and relay execution context. Treat this as an integration boundary artifact
(constructed by your relay adapter/backend integration), not application
business-logic input.

The exact shape is current-branch API and may evolve as quote-source
integration evolves.

### Behavioral Guarantees

- `batch` and `signedBatch` reject empty call arrays.
- `batch` does not auto-upgrade already delegated accounts; upgrade remains
  explicit.
- `signedBatch` keeps signing factor-neutral: caller signs digest, SDK binds
  envelope domain/message deterministically.
- `relay` performs SDK-owned relay preflight before relay execute.
- `relay` direct fallback can be unsigned direct (default) or signed direct
  (`directExecution: 'signed'`, requires `signedExecute`).
- `relay` returns lifecycle context in `{ prepared?, statusSnapshot?, flow, directResult? }`.

### `policyContext` (Execution-time)

`delegation.delegate`, `execute.batch`, `execute.signedBatch`, and
`execute.relay` accept optional:

```ts
policyContext: {
  policy,
  principalId,
}
```

Caller supplies identity context. SDK derives operation facts from the actual
execution plan and performs policy preflight before send.

## `policy` Namespace

### Domain

Policy mutation authoring/execution and runtime-aware policy reads.

### Contains

| Member                                                                                                      | Kind               | Contract                                                                    |
| ----------------------------------------------------------------------------------------------------------- | ------------------ | --------------------------------------------------------------------------- |
| `apply({ chainId, changes, transactionOptions, nonce, ...clients })`                                        | Execute            | Executes one or more policy mutations through delegated account self-calls. |
| `setCallRule({ keyHash, target, selector, allowed })`                                                       | Descriptor builder | Returns one `setCallPermission` mutation descriptor.                        |
| `setSpendLimit({ keyHash, token, period, limit, mode })`                                                    | Descriptor builder | Returns one spend-limit mutation descriptor.                                |
| `setFeeLimit({ keyHash, token, period, limit })`                                                            | Descriptor builder | Returns one fee-limit mutation descriptor.                                  |
| `setNonceLaneRule({ keyHash, lane, allowed })`                                                              | Descriptor builder | Returns one nonce-lane permission mutation descriptor.                      |
| `forAccount({ publicClient, accountAddress, chainId, readCode?, runtimeContractAddress?, stateOverride? })` | Reader factory     | Returns runtime-aware reader bound to one account runtime context.          |

### `forAccount(...)` Reader Surface

- `getCallRule({ keyHash, target, selector })`
- `getNonceLaneRule({ keyHash, lane })`
- `getSpendLimit({ keyHash, token, period })`
- `getSpendLimitMode({ keyHash, token, period })`
- `getFeeLimit({ keyHash, token, period })`
- `getSpendUsage({ keyHash, token, period })`
- `getFeeUsage({ keyHash, token, period })`

### Behavioral Guarantees

- `apply` fails closed unless verified runtime capability supports onchain
  mutation operations.
- descriptor builders are structural; onchain validation happens in mutation
  encoding/preflight.
- lane `0` is reserved and rejected for configurable nonce-lane mutation.
- `forAccount` reads are runtime-aware and can resolve runtime code via state
  override when account runtime bytecode is not directly present.

## `factor` Namespace

### Domain

Factor abstraction for execution client resolution and deterministic onboarding
selection.

### Contains

| Member                                                                     | Kind                  | Contract                                                                      |
| -------------------------------------------------------------------------- | --------------------- | ----------------------------------------------------------------------------- |
| `passkey({ walletClient, publicClient, factorId?, authorize? })`           | Constructor           | Creates a passkey factor with optional pre-resolution authorization hook.     |
| `externalWallet({ signer, provider, chainId, factorId? })`                 | Constructor           | Creates an external-wallet factor from ethers signer/provider input.          |
| `custom({ factorId, factorType, resolveClientInput })`                     | Constructor           | Creates a custom execution factor.                                            |
| `resolve({ factor, chainId })`                                             | Resolver              | Resolves factor client input and validates chain coherence.                   |
| `onboarding.preferredType({ availableFactorTypes, preferredFactorType? })` | Onboarding selector   | Deterministically chooses onboarding factor type.                             |
| `onboarding.select({ factors, preferredFactorType? })`                     | Onboarding selector   | Returns selected onboarding factor instance.                                  |
| `onboarding.hasAlternative({ factors, primaryFactorType? })`               | Onboarding continuity | Returns whether a non-custodial alternative exists.                           |
| `onboarding.baselines()`                                                   | Baseline matrix read  | Returns deterministic baseline matrix for supported/unsupported factor types. |
| `onboarding.baseline(factorType)`                                          | Baseline read         | Returns one baseline entry.                                                   |

### Behavioral Guarantees

- `resolve` rejects mismatched chain-constrained factor outputs.
- onboarding selection is deterministic and stable across callers for the same
  inputs.
- passkey factor can gate per-chain authorization before exposing client input.

## `authority` Namespace

### Domain

Control-key lifecycle mutations and authority-root governance reads.

### Contains

| Member                                                                                                                                                                                              | Kind           | Contract                                                                               |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------- | -------------------------------------------------------------------------------------- |
| `hashControlKey(controlKey)`                                                                                                                                                                        | Utility        | Hashes control-key descriptor to key hash.                                             |
| `register({ controlKey, role?, expiration?, hook?, setAsAuthorityRoot?, chainId, transactionOptions, nonce, ...clients })`                                                                          | Execute        | Registers control key and optional authority-root role/settings in one mutation batch. |
| `rotate({ currentControlKeyHash, nextControlKey, role?, expiration?, hook?, revokeCurrent?, setNextAsAuthorityRoot?, clearCurrentAuthorityRoot?, chainId, transactionOptions, nonce, ...clients })` | Execute        | Rotates authority key and optional root assignments.                                   |
| `revoke({ controlKeyHash, chainId, transactionOptions, nonce, ...clients })`                                                                                                                        | Execute        | Revokes one authority/control key hash.                                                |
| `addAuthorityRoot({ controlKeyHash, chainId, transactionOptions, nonce, ...clients })`                                                                                                              | Execute        | Enables authority-root membership for a key hash.                                      |
| `removeAuthorityRoot({ controlKeyHash, chainId, transactionOptions, nonce, ...clients })`                                                                                                           | Execute        | Disables authority-root membership for a key hash.                                     |
| `update({ keyHash, patch, chainId, transactionOptions, nonce, ...clients })`                                                                                                                        | Execute        | Patches role/expiration/hook for an already-registered key.                            |
| `forAccount({ publicClient, accountAddress, chainId, readCode?, runtimeContractAddress?, stateOverride? })`                                                                                         | Reader factory | Returns runtime-aware authority reader.                                                |

### `forAccount(...)` Reader Surface

- `isRegistered({ keyHash })`
- `getSettings({ keyHash })`
- `getKeyState({ keyHash, nowUnix? })`
- `isAuthorityRoot({ keyHash })`
- `authorityRootCount()`
- `protocolRootState()`

### Behavioral Guarantees

- mutation methods execute through delegated self-call path with runtime
  capability verification.
- `update` fails with explicit `AuthorityUpdateError` codes
  `ROOT_KEY_PATCH_DENIED` and `KEY_NOT_REGISTERED`.
- `getKeyState` includes root-key and unregistered-key explicit states, so
  callers can branch without extra reads.

## `recovery` Namespace

### Domain

Protocol-root governance toggling and protocol-root recovery lifecycle.

### Contains

| Member                                                                              | Kind    | Contract                                                           |
| ----------------------------------------------------------------------------------- | ------- | ------------------------------------------------------------------ |
| `disableProtocolRoot({ chainId, transactionOptions, nonce, ...clients })`           | Execute | Sets protocol-root governance disabled flag to `true`.             |
| `enableProtocolRoot({ chainId, transactionOptions, nonce, ...clients })`            | Execute | Sets protocol-root governance disabled flag to `false`.            |
| `request({ chainId, transactionOptions, nonce, ...clients })`                       | Execute | Requests protocol-root recovery.                                   |
| `execute({ authorityRootKeyHash, chainId, transactionOptions, nonce, ...clients })` | Execute | Executes protocol-root recovery to target authority-root key hash. |
| `cancel({ chainId, transactionOptions, nonce, ...clients })`                        | Execute | Cancels pending protocol-root recovery.                            |
| `status({ publicClient, accountAddress, stateOverride? })`                          | Read    | Reads protocol-root governance/recovery state.                     |

### Behavioral Guarantees

- recovery mutations reuse the same delegated mutation execution path as
  authority mutations.
- `status` is an onchain read and can be used independently of mutation calls.

## Hook Exports

### `useDelegations(address)`

Subscribes to active delegations for the address and returns
`DelegationWithChainId[]`.

### `useDelegationDisabled(address)`

Subscribes to the local delegation-disabled signal for the address and returns
`boolean`.

### `useWillDelegate(address, chainId)`

Subscribes to whether current store state indicates that the next batched
execution would require delegation authorization.

## Minimal End-to-End Example

```ts
configure({ platformClient, logger, getCurrentAddress });

const support = await delegation.isSupported({ address, chainId });
if (!support.supported) return;

const nonce = await publicClient.getTransactionCount({ address });

const prepared = await execute.prepare({
  from: address,
  calls,
  chainId,
  nonce,
});

const result = await execute.batch({
  walletClient,
  publicClient,
  chainId,
  calls,
  nonce,
  transactionOptions: {
    maxFeePerGas,
    maxPriorityFeePerGas,
    gasLimit: null,
  },
  policyContext: {
    policy,
    principalId,
  },
});
```

Use `execute.relay(...)` for relay execution, passing a `relay` adapter config
from your integration layer.
