# Rainbow Wallet SDK

Rainbow's transaction and account-runtime SDK.

This SDK is the client execution foundation for wallet transaction sending,
account authority management, and policy-aware runtime interaction.

It is organized around one rule:

- callers provide business intent (`calls`, `route`, `sponsorship`, factor
  inputs)
- the SDK owns execution correctness (delegation/runtime preflight, policy
  preflight, relay-commitment verification, deterministic fallback)

## Installation

Required peers:

```bash
yarn add viem@^2.38.0 @storesjs/stores@^0.8.6
```

Optional peers:

- `react` (only for hooks)
- `ethers` (only for ethers client inputs)

## Configure Once

Call `configure(...)` before using namespace methods or hooks.

```ts
configure({
  platformClient,
  logger,
  getCurrentAddress,
  // optional
  storeOptions,
  readAccountCode,
  resolveDelegationCapability,
});
```

Required services:

- `platformClient`
- `logger`
- `getCurrentAddress`

Optional services:

- `storeOptions`: storage/sync config for persisted stores
- `readAccountCode`: chain-aware runtime-code reader used by
  `delegation.isSupported`, `delegation.willDelegate`, and `execute.prepare`
  to correct stale backend `NOT_DELEGATED` states with onchain code truth
- `resolveDelegationCapability`: environment-level capability resolver override
  for non-production deployments with different runtime/capability metadata

## Root API Surface

The root package exports:

- `configure`
- `delegation`
- `execute`
- `policy`
- `factor`
- `authority`
- `recovery`
- hooks: `useDelegations`, `useDelegationDisabled`, `useWillDelegate`
- types: `Services`, `ActiveDelegations`, `DelegationWithChainId`

## Namespace Ownership

### `delegation`

Owns delegation support/readiness checks and explicit delegation lifecycle.

- reads: `isSupported`, `willDelegate`, `active`, `shouldRevoke`
- executes: `delegate`, `revoke`
- local user preference state: `enable`, `disable`, `isEnabled`

### `execute`

Owns transaction execution paths.

- `prepare`: build simulation transaction shape
- `batch`: batched direct/delegated execution path
- `signedBatch`: signed-execute envelope path
- `intent`: SDK-owned relay intent path with transport adapter

### `policy`

Owns policy mutation descriptors/execution and runtime-aware policy reads.

- mutation entry: `apply`
- descriptor builders: `setCallRule`, `setSpendLimit`, `setFeeLimit`,
  `setNonceLaneRule`
- runtime reader factory: `forAccount`

### `authority`

Owns control-key lifecycle and authority-root operations.

- key lifecycle: `register`, `rotate`, `revoke`, `update`
- authority-root toggles: `addAuthorityRoot`, `removeAuthorityRoot`
- utilities/readers: `hashControlKey`, `forAccount`

### `recovery`

Owns protocol-root governance recovery operations.

- toggles: `disableProtocolRoot`, `enableProtocolRoot`
- lifecycle: `request`, `execute`, `cancel`
- read: `status`

### `factor`

Owns factor construction/resolution and onboarding helpers.

- constructors: `passkey`, `externalWallet`, `custom`
- client resolution: `resolve`
- onboarding: `onboarding.preferredType`, `onboarding.select`,
  `onboarding.hasAlternative`, `onboarding.baselines`,
  `onboarding.baseline`

## Client Input Model

Transaction methods accept either:

- viem input: `{ walletClient, publicClient, ... }`
- ethers input: `{ signer, provider, chainId, ... }`

The SDK normalizes both to viem clients internally.

## Minimal Flow

```ts
configure({ platformClient, logger, getCurrentAddress });

const support = await delegation.isSupported({ address, chainId });
if (!support.supported) return;

const nonce = await publicClient.getTransactionCount({ address });

const simulationTx = await execute.prepare({
  from: address,
  calls,
  chainId,
  nonce,
});

const result = await execute.batch({
  walletClient,
  publicClient,
  chainId,
  calls,
  nonce,
  transactionOptions: {
    maxFeePerGas,
    maxPriorityFeePerGas,
    gasLimit: null,
  },
  policyContext: {
    policy,
    principalId,
  },
});
```

## Relay Intent Flow (`execute.intent`)

`execute.intent(...)` is the client-facing relay boundary.

Callers provide business-owned route and transport inputs. The SDK owns
request-id generation (unless explicitly supplied), relay preflight integrity,
and deterministic fallback behavior.

```ts
const result = await execute.intent({
  walletClient,
  publicClient,
  chainId,
  calls,
  nonce,
  transactionOptions,
  intent: {
    route: { chainSetHash },
    sponsorship: 'unsponsored',
    transport: {
      quoteSigner,
      prepare,
      execute,
      getStatus,
    },
  },
});
```

Intent transport contract:

- `prepare(context)` receives
  `{ chainId, account, value?, calls, delegationDecision, requestId, route, sponsorship? }`
- `execute(prepared)` returns `{ bundleId }`
- `getStatus(bundleId)` returns status snapshots

If `signedExecute` is provided, intent fallback uses signed direct execution;
otherwise it uses the standard direct batch path.

## Delegation Deployments

Delegation contract mapping is defined in
`src/contract/addresses.ts` via `DELEGATION_ADDRESSES` and currently resolves
supported chains to `RAINBOW_CALIBUR_CANONICAL_ADDRESS`.

If a chain is not mapped, delegation authorization paths fail closed for that
chain.

## Deeper Documentation

- context/injection model: `src/context/README.md`
- relay correctness model: `src/relay/README.md`
- relay intent verification details: `src/relay/intent-model/README.md`
