# Relay Architecture

`src/relay` is the SDK's relay correctness core.

Its job is narrow and strict:

> Given a prepared relay package and a direct fallback path, produce one
> deterministic execution decision and one deterministic status outcome.

This module is protocol logic, not transport glue.

## Why this module exists

Direct execution has one trust boundary: client intent + chain execution.

Relay execution adds a second boundary: backend `prepare` output. That creates
two system risks if left unmodeled:

1. trust drift: client signs against mismatched or tampered prepared data
2. fallback drift: each caller/provider invents different relay failure behavior

`src/relay` exists to keep both impossible under normal integration.

## Core invariants

These are module guarantees, not suggestions:

- integrity failures do not auto-fallback
- fallback must preserve sponsorship semantics
- fallback is class-based and deterministic
- relay/direct legs reduce to one status contract
- transport adapters are replaceable; integrity semantics are not

If a change weakens any invariant above, treat it as a regression.

## Ownership boundaries

This module owns:

- intent/binding hash logic
- prepare-response signature and digest verification
- quote-time acceptance
- failure classification and fallback policy
- lifecycle orchestration (`prepare` / `execute` / `getStatus` / direct)
- unified status reduction
- idempotency and circuit-breaker helper primitives

This module does not own:

- provider-specific HTTP contracts
- backend quote generation/pricing policy
- onchain authority/policy enforcement
- app-level retry UX or telemetry persistence

Boundary rule:

- adapters translate provider contracts into SDK transport shape
- `src/relay` decides if relay execution is valid and how outcomes are reduced

## Integration boundary in this SDK

Public relay entrypoint: `execute.intent(...)`.

Primary action owners:

- `src/actions/executeIntentBatchedTransaction.ts`
- `src/actions/internal/preflightRelay.ts`
- `src/actions/internal/relayExecution.ts`

Execution order:

1. resolve delegation decision
2. optional policy preflight
3. run intent transport `prepare(context)`
4. verify prepared commitment against local intent
5. execute relay path when valid
6. poll relay status
7. apply deterministic fallback policy when required
8. reduce relay/direct legs into unified execution flow

If `signedExecute` is present, direct fallback uses signed direct execution;
otherwise it uses standard batched direct execution.

## Commitment model

`prepare` returns `RelayInput`, which contains a signed commitment package:

- relay domain: `relayId`, `relayVersion`, `environment`, `chainSetHash`,
  `quoteSigner`
- quote payload: quote id/time window/fee terms/sponsorship
- response binding: `quoteDigest`, `executionDigest`, `callsHash`,
  `clientRequestId`
- backend signature over response binding
- fee-derivation metadata for local arithmetic verification

Prepare binding signature uses EIP-712 typed data:

- domain name: `RainbowRelayPrepare`
- domain version: `1`

The envelope is format. Security comes from local digest recomputation +
ordered validation.

## Validation stages

`preflightRelay(...)` validates in two stages.

### Stage 1: trust guards

Before deep validation:

- expected quote signer must match prepared domain
- expected chain-set hash must match prepared domain
- optional sponsorship expectation must match prepared quote semantics

This rejects wrong-domain prepared payloads early.

### Stage 2: prepared quote validation

`validatePreparedQuote(...)` enforces ordered checks:

1. quote time acceptance
2. fee-derivation hash equivalence
3. derived max-fee equivalence and policy bounds
4. quote digest equivalence
5. calls hash equivalence
6. execution digest equivalence
7. client request id equivalence
8. signature authenticity and signer match

Relay execute cannot proceed unless all checks pass.

## Failure classes and fallback

`fallbackPolicy.ts` defines class-to-decision mapping.

Current policy shape:

- integrity failure -> `NO_AUTO_FALLBACK`
- quote expiry -> `REPREPARE_ONCE`, then guarded direct fallback
- transport failure -> guarded direct fallback
- sponsorship required -> `FAIL_CLOSED`
- unknown failure -> `FAIL_CLOSED`

"Guarded" means direct fallback is blocked unless sponsored semantics are
preserved and direct execution is supported.

## Unified status contract

`statusReducer.ts` and `executionFlow.ts` reduce outcomes to:

- `SUBMITTING`
- `PENDING`
- `CONFIRMED_RELAY`
- `CONFIRMED_DIRECT`
- `FAILED`

with provenance:

- `executionPath`: `relay` | `direct` | `hybrid`
- relay bundle id
- direct tx hash
- per-leg failure metadata

Goal: callers never invent local precedence rules for hybrid outcomes.

## Transport contracts

Generic relay transport (`src/relay/transport.ts`):

```ts
type Transport<TPrepared> = {
  prepare: (context: { chainId: number }) => Promise<TPrepared>;
  execute: (prepared: TPrepared) => Promise<{ bundleId: string }>;
  getStatus: (bundleId: string) => Promise<BundleStatusSnapshot>;
};
```

Intent transport (`execute.intent`) is richer at the public boundary and
receives route/sponsorship/request/delegation context before being wrapped into
internal `Transport<RelayInput>` lifecycle shape.

Adapter obligations:

1. `prepare` returns verifiable commitment data
2. `execute` executes the prepared package, not a reinterpretation
3. `getStatus` reports monotonic progress to terminal states
4. provider errors map stably into fallback classes

## Digest split rationale

Digest separation is intentional and ownership-driven:

- `callsHash`: binds ordered call tuples
- `executionDigest`: binds execution envelope (chain/account/delegation/fee/
  request identity)
- `quoteDigest`: binds relay domain + quote payload + intent bindings

Keeping these separate prevents semantic collapse into one opaque hash and
keeps verification failures explainable.

## Operational helpers

- `idempotency.ts`: deterministic logical-intent/attempt ids
- `circuitBreaker.ts`: pure threshold evaluation for relay quarantine signals

These helpers are pure; persistence and traffic control remain external.

## File map

- `intentHash.ts`
- `quoteDigest.ts`
- `responseDigest.ts`
- `quoteTime.ts`
- `prepareValidation.ts`
- `fallbackPolicy.ts`
- `lifecycle.ts`
- `executionFlow.ts`
- `statusReducer.ts`
- `transport.ts`
- `idempotency.ts`
- `circuitBreaker.ts`

## Related docs

- root execution entrypoint context: `README.md`
- relay intent verification details: `src/relay/intent-model/README.md`
- broader verification framing: `verification-model.md`
