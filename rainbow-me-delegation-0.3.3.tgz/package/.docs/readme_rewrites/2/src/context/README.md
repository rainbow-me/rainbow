# Context and Dependency Injection

`src/context` defines the SDK's runtime boundary.

It provides:

- one configuration boundary (`configure`)
- one service container (`getServices`)
- one action wrapper (`defineAction`)
- one client-normalization layer (viem + ethers inputs)

This boundary exists so public API methods ask callers only for caller-owned
inputs while platform and environment dependencies are injected once.

## Module Layout

```text
context/
├── types.ts         # service contracts and configure input types
├── container.ts     # configure/getServices lifecycle
├── clients.ts       # viem/ethers normalization
├── defineAction.ts  # typed injection wrapper
└── index.ts         # public exports
```

## Service Model

`configure(configuration)` stores services globally and initializes the
store layer.

Required services:

- `platformClient`
- `logger`
- `getCurrentAddress`

Optional services:

- `storeOptions`
- `readAccountCode`
- `resolveDelegationCapability`

```ts
configure({
  platformClient,
  logger,
  getCurrentAddress,
  storeOptions,
  readAccountCode,
  resolveDelegationCapability,
});
```

### Why optional services live here

`readAccountCode` and `resolveDelegationCapability` are environment-level truth
sources, not per-call business inputs.

- `readAccountCode` is used for stale-backend correction in
  `delegation.isSupported`, `delegation.willDelegate`, and `execute.prepare`.
- `resolveDelegationCapability` lets non-production environments override
  capability metadata while keeping public method signatures clean.

## `defineAction` Contract

`defineAction` wraps internal action owners and produces public call signatures.

Behavior:

- normalizes input clients (`walletClient/publicClient` or
  `signer/provider/chainId`)
- validates chain-id coherence when `chainId` is provided
- injects configured services from the container
- removes injected keys from the external call signature

That last point is critical: injected/service keys remain internal, so they do
not leak into public namespace params.

## External Signature Model

`defineAction` applies an `Externalize<P>` transform:

- input is action owner params `P`
- keys owned by `ClientOutput & Services` are stripped from external params
- caller-facing params become: remaining domain params + `ClientInput`

This keeps API signatures focused on user intent and protects against
accidental public exposure of internal dependency knobs.

## Client Inputs

Bound methods accept exactly one client shape:

- viem input: `{ walletClient, publicClient }`
- ethers input: `{ signer, provider, chainId }`

Ethers inputs are normalized to viem clients internally.

Ethers requirements:

- `signer` must expose a wallet-like `privateKey`
- `provider` must expose an RPC URL

## Runtime Validation Rules

Context enforces boundary invariants:

- `configure` must run before bound methods execute
- viem wallet clients must include an account
- ethers signer/provider must resolve to the same RPC source
- explicit `chainId` must match normalized public and wallet client chains
  (when chain metadata is present)

These guarantees let action modules operate on a coherent, already-normalized
execution context.

## Design Intent

Context is intentionally small and strict:

- one place to bind platform dependencies
- one way to normalize client inputs
- one path to inject internals without leaking them into public API

If a new dependency varies per environment, it belongs in `configure`.
If it varies per call and is business-owned, it belongs in namespace params.
