# Delegate v4 Architecture Package

This version keeps v3 immutable and closes remaining protocol-spec completeness gaps.

Files:

- `DELEGATE_ARCHITECTURE_CORRECTIONS_AND_REFINEMENT.md`
- `DELEGATE_SESSION_ARCHITECTURE.md`

v4 focus:

- SRP request-kind support for operator enrollment
- explicit hash composition (`coreHash`, `callbackHash`, root hash)
- explicit typed receipt tuple hashing
- wildcard-to-Calibur sentinel compilation contract
