# Delegate v2 Architecture Package

This version contains architecture-only outputs:

- `DELEGATE_ARCHITECTURE_CORRECTIONS_AND_REFINEMENT.md`
- `DELEGATE_SESSION_ARCHITECTURE.md`

Scope choice is deliberate: architecture is settled before any CLI-spec revision.
