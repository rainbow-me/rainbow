# Delegate v9 Design Package

v9 is a focused product architecture for agent-administered Rainbow session keys funded via external spending credit.

It keeps v7 runtime correctness and recasts the surface around accountable humans and real deployment flows.

Files:

- `DELEGATE_V9_FOUNDATION.md`
  - concrete actor model (owner, agent admin, runtime, funding source)
  - credit/budget/liquidity separation
  - approval UX and funnel thesis
  - v9 ship criteria
- `DELEGATE_V9_AGENT_CLI_SPEC.md`
  - focused CLI contract for enroll/grant/credit/fund/use/revoke
  - deterministic outputs, recovery semantics, and inspect views
  - compatibility path from v7

v9 stance:

1. concrete humans first, not abstract operators
2. minimal complete scope for market-now stickiness
3. external credit ingress as first-class product concept
4. safe composable primitives for future expansion
