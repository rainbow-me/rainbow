# Delegate v7 Design Package

This package supersedes `v6` as the canonical Delegate design set.

Files:

- `review/DELEGATE_V7_REVIEW_OF_REVIEW.md` (self-audit of prior review and residual gaps)
- `review/DELEGATE_V7_EXTERNAL_REVIEW_RECONCILIATION.md` (independent validation and integration of external review findings)
- `DELEGATE_SESSION_ARCHITECTURE.md` (canonical v7 architecture)
- `DELEGATE_CLI_SPEC.md` (canonical v7 CLI product/runtime contract)
- `DELEGATE_API_ADDENDUM.md` (canonical v7 API and primitive type map)

v7 closure matrix:

- account vs submitter split -> architecture §4, §5.4, §11.2 and CLI §4.6, §6.1
- mutation nonce determinism -> architecture §6 and CLI §4.7
- mode-transition correctness -> architecture §7.2 and CLI §7.5, §7.6
- chain-scoped idempotency identity -> architecture §7.2 and CLI §7.5
- session schema/signer resolution coherence -> CLI §4.3, §4.5
- operator enrollment cardinality and signer-binding invariants -> architecture §5.6, §9.1 and CLI §4.3, §4.5, §7.12
- explicit executor policy -> architecture §5.3 and CLI §4.8
- crash-safe/finality-safe budget idempotency lifecycle -> architecture §7.2, §7.4 and CLI §7.5
- first-class funding ingress abstraction (`CreditGrant`) -> architecture §7.5 and CLI §7.13, §7.14
- finality/reorg truth contract -> architecture §8.4 and CLI §4.9, §6.2
