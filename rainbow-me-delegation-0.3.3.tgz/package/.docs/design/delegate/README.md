# Delegate Design Workspace

Versioned design artifacts for the Delegate product.

## Structure

- `v0/`
  - Original drafts moved from repo root:
    - `RAINBOW_SESSION_ARCHITECTURE.md`
    - `RAINBOW_AGENT_CLI_SPEC.md`
- `v1/`
  - Refined replacement designs:
    - `DELEGATE_SESSION_ARCHITECTURE.md`
    - `DELEGATE_CLI_SPEC.md`
- `v2/`
  - Evidence-backed architecture revision package:
    - `README.md`
    - `DELEGATE_ARCHITECTURE_CORRECTIONS_AND_REFINEMENT.md`
    - `DELEGATE_SESSION_ARCHITECTURE.md`
- `v3/`
  - Deepened architecture package for implementation-readiness:
    - `README.md`
    - `DELEGATE_ARCHITECTURE_CORRECTIONS_AND_REFINEMENT.md`
    - `DELEGATE_SESSION_ARCHITECTURE.md`
- `v4/`
  - Spec-completeness architecture package:
    - `README.md`
    - `DELEGATE_ARCHITECTURE_CORRECTIONS_AND_REFINEMENT.md`
    - `DELEGATE_SESSION_ARCHITECTURE.md`
- `v5/`
  - Final architecture package:
    - `README.md`
    - `DELEGATE_ARCHITECTURE_CORRECTIONS_AND_REFINEMENT.md`
    - `DELEGATE_SESSION_ARCHITECTURE.md`
- `v6/`
  - Final convergence package:
    - `README.md`
    - `DELEGATE_ARCHITECTURE_CORRECTIONS_AND_REFINEMENT.md`
    - `DELEGATE_SESSION_ARCHITECTURE.md`
    - `DELEGATE_CLI_SPEC.md`
- `v7/`
  - Coherence and correctness package:
    - `README.md`
    - `review/DELEGATE_V7_REVIEW_OF_REVIEW.md`
    - `review/DELEGATE_V7_EXTERNAL_REVIEW_RECONCILIATION.md`
    - `DELEGATE_SESSION_ARCHITECTURE.md`
    - `DELEGATE_CLI_SPEC.md`
    - `DELEGATE_API_ADDENDUM.md`
- `v8/`
  - Operator-first product packaging on top of v7 primitives:
    - `README.md`
    - `DELEGATE_V8_OPERATOR_ARCHITECTURE.md`
    - `DELEGATE_V8_CLI_SPEC.md`
    - `DELEGATE_V8_MARKET_WEDGE.md`
- `v9/`
  - Agent-admin focused product architecture and CLI:
    - `README.md`
    - `DELEGATE_V9_FOUNDATION.md`
    - `DELEGATE_V9_AGENT_CLI_SPEC.md`

## Notes

`v1` treats current SDK surface APIs as mutable and proposes target abstractions that minimize long-term architectural regret.
`v2` keeps `v1` immutable and adds explicit correction trails, source citations,
and a canonical architecture marked by epistemic status.
`v3` keeps `v2` immutable and deepens the canonical architecture where v2 was
too thin for implementation (SRP hash contract, operator enrollment mechanics,
funding-model rationale).
`v4` keeps `v3` immutable and closes remaining protocol completeness gaps
(operator-enrollment protocol fit, explicit callback/core/receipt hash contracts,
and wildcard-to-sentinel compilation semantics).
`v5` keeps `v4` immutable and publishes the final canonical architecture with
iteration artifacts removed and remaining SRP/receipt edge-case ambiguities
closed for deterministic cross-implementation behavior.
`v6` keeps `v5` immutable and closes the remaining implementation-level
determinism gaps (budget lock granularity, per-section uniqueness semantics,
expiration-zero normalization, callback normalization constraints, and fixed
sorting comparator semantics), then adds the canonical CLI specification built
on the settled architecture.
`v7` keeps `v6` immutable and closes remaining coherence gaps that still blocked
safe operator-scale deployment (target-account vs submitter separation, explicit
nonce allocation for all mutation paths, chain-scoped idempotency payload
identity, mode-transition zero-usage preconditions, finality-aware receipt
reconciliation, and fleet-revoke truth semantics).
`v8` keeps `v7` immutable and reframes the product surface around operator
intent verbs (`setup`, `grant`, `fund`, `use`, `revoke`) while preserving v7's
runtime and safety contracts. It explicitly scopes to a market-now operator loop
and defers multinational budgeting complexity.
`v9` keeps `v7` and `v8` immutable and tightens scope around concrete actors
from the original brief (account owner, accountable agent admin, runtime, and
funding source), with a focused session-credit architecture and an agent-admin
CLI contract optimized for real near-term deployment and Rainbow funnel growth.
