# Delegate v3 Architecture Package

This version is architecture-only and keeps prior versions immutable.

Files:

- `DELEGATE_ARCHITECTURE_CORRECTIONS_AND_REFINEMENT.md`
- `DELEGATE_SESSION_ARCHITECTURE.md`

v3 focus:

- deeper implementation-grade SRP canonicalization/hash contract
- explicit operator enrollment mechanics and scope bounds
- expanded funding-model rationale and budget API semantics
