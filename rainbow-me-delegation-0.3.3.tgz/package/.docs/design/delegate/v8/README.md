# Delegate v8 Design Package

This package preserves the v7 primitive substrate and defines the v8 operator-first product shape.

Files:

- `DELEGATE_V8_OPERATOR_ARCHITECTURE.md`
  - Canonical v8 architecture
  - Intent verbs and state machine
  - Minimal stable primitives for the next phase
- `DELEGATE_V8_CLI_SPEC.md`
  - Operator-first command surface (`setup`, `grant`, `fund`, `use`, `revoke`)
  - Admin namespace for low-level operations
  - Deterministic automation/output contracts
- `DELEGATE_V8_MARKET_WEDGE.md`
  - Market-now scope
  - Sticky loop and funnel thesis
  - release and metrics plan

v8 stance:

- Keep v7 correctness contracts.
- Reduce front-door complexity.
- Treat phase-level complexity as control-plane implementation detail.
- Ship the smallest sticky operator loop that works now.
