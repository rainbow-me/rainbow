# Relay intents documentation

`v0/` is the first versioned pass.

`v1/` is the previous redesign pass.

`v2/` is the current working set.

Design artifacts for `v2/` live inside the versioned directory itself:

- [v2/brief.md](v2/brief.md)
- [v2/structure.md](v2/structure.md)
- [v2/journal.md](v2/journal.md)

Read the current set in this order:

1. [v2/relay-intents-overview.md](v2/relay-intents-overview.md)
2. [v2/intent-relay-architecture-v2.md](v2/intent-relay-architecture-v2.md)
3. [v2/relay-reference-gateway.md](v2/relay-reference-gateway.md)
4. [v2/relay-link-api-examples.md](v2/relay-link-api-examples.md)
