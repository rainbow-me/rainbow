# Lock document index

Authoritative lock set:

- `docs/locks/RAINBOW_RELAY_DESIGN_LOCKED_V4.md`
- `docs/locks/RAINBOW_CONTRACT_STACK_LOCKED_V3.md`
- `docs/locks/RAINBOW_DESIGN_SECOND_DEEP_PASS_AUDIT.md`
- `docs/locks/RAINBOW_DESIGN_LOCK_MANIFEST_2026-02-21.md`

Superseded lock artifacts remain in this directory for historical traceability:

- `docs/locks/RAINBOW_RELAY_DESIGN_LOCKED_V3.md`
- `docs/locks/RAINBOW_DESIGN_LOCK_MANIFEST_2026-02-20.md`

Historical source copies from `~/Downloads` were moved to:

- `.archived/downloads-root/`
