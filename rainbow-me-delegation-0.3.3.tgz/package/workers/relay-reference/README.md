# Relay Backend Reference

Reference Cloudflare Workers backend for the SDK's `IntentRelayTransport`.

## Components

- `gateway/`: public worker that serves the relay HTTP API and routes execution state into the Durable Object
- `signer/`: internal signing worker used through a service binding
- `shared/`: worker-shared contracts and types

Public routes:

- `POST /v1/executions/prepare`
- `POST /v1/executions/{executionId}/execute`
- `POST /v1/executions/{executionId}/wallet-results`
- `GET /v1/executions/{executionId}/status`

Further detail lives in:

- [reference gateway architecture](../../architecture-docs/relay/2-reference-gateway.md)
- [`DEPLOYMENT.md`](DEPLOYMENT.md)

## Local development

Copy the local env templates:

```bash
cp workers/relay-reference/signer/.dev.vars.example workers/relay-reference/signer/.dev.vars.development
cp workers/relay-reference/gateway/.dev.vars.example workers/relay-reference/gateway/.dev.vars.development
```

Set the signer private key in `signer/.dev.vars.development` and the matching `QUOTE_SIGNER_ADDRESS` plus `RELAY_LINK_API_KEY` in `gateway/.dev.vars.development`, then start the stack:

```bash
yarn workers:relay-reference:dev
```

The launcher uses the Wrangler `development` environment by default, validates the signer/address match, and writes `workers/relay-reference/.dev-stack.json` for local consumers.

## Validation

Run from repo root:

```bash
./node_modules/.bin/tsc -p workers/relay-reference/gateway/tsconfig.json --noEmit
./node_modules/.bin/tsc -p workers/relay-reference/signer/tsconfig.json --noEmit
npx -y node@22 ./node_modules/.bin/vitest run --config workers/relay-reference/gateway/vitest.config.ts
```

## Deploy

See [`DEPLOYMENT.md`](DEPLOYMENT.md).
