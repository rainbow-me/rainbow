# @rainbow-me/delegation

## 0.3.3

### Patch Changes

- 144e217: Increase optimistic conflict window from 1 minute to 2 minutes to better protect local writes from stale backend reads

## 0.3.2

### Patch Changes

- bb9d317: Return transaction request data from execute functions

  `ExecutionResult` now includes a `transaction` field typed as a viem `TransactionRequestEIP1559 | TransactionRequestEIP7702`, exposing the full prepared transaction params (including resolved `gas`, `maxFeePerGas`, `maxPriorityFeePerGas`, etc.) alongside the `hash`.

  ```typescript
  type ExecutionResult =
    | { hash: Hash; type: 'eip1559'; transaction: TransactionRequestEIP1559 }
    | { hash: Hash; type: 'eip7702'; transaction: TransactionRequestEIP7702 };
  ```

## 0.3.1

### Patch Changes

- dd98463: Remove `chains` from `configure()`. Actions accept any chain — the ethers path derives what it needs from the supplied `chainId` and `provider` RPC URL.

  `DELEGATION_ADDRESSES` is the sole authority on which chains support delegation.

## 0.3.0

### Minor Changes

- abe3257: **API Changes**

  `configure()`

  - `currentAddress` renamed to **`getCurrentAddress`** and now required: `($: DeriveGetter) => Address | null`
  - `storeOptions.sync` is now required when `storeOptions` is provided

  `delegationPreference()` — removed

  - Use `isDelegationEnabled` / `enableDelegation` / `disableDelegation`

  `useDelegationPreference()` — removed

  - Use `useDelegationDisabled` + standalone enable/disable functions

  `getDelegations()` — return type changed

  - Now returns `DelegationWithChainId[]`. Only includes chains where the wallet is actively delegated (`RAINBOW_DELEGATED` or `THIRD_PARTY_DELEGATED`).
    ```ts
    type DelegationWithChainId = {
      chainId: number;
      delegationStatus: DelegationStatus;
      revokeReason: RevokeReason | null;
      revokeAddress: Address | null;
      updateReason: UpdateReason | null;
      currentContract: Address | null;
      currentContractName: string | null;
      latestContract: Address | null;
    };
    ```

  `useDelegations(address)` — return type changed

  - Returns `DelegationWithChainId[]` directly, same type as `getDelegations()`. The `isLoading` property is removed; fresh status is fetched internally on mount.

  `willDelegate()` — return type, params, and behavior changed

  - `WillDelegateResult.delegation` is now `DelegationContract | null` (shape unchanged)
    ```ts
    type DelegationContract = {
      chainId: number;
      contractAddress: Address;
    };
    ```
  - New optional param **`requireFreshStatus?: boolean`** (default `false`) — bypasses cache on pre-execution paths
  - No longer returns `true` for upgrade-available states. Returns `true` only for `NOT_DELEGATED` or `THIRD_PARTY_DELEGATED` where the backend signals `RAINBOW_ONBOARDING` or `UPGRADE_AVAILABLE`. All `RAINBOW_DELEGATED` states (including upgrade-available) short-circuit to `false`. Note: `executeDelegation()` bypasses this short-circuit and will still authorize for `RAINBOW_DELEGATED` wallets when an upgrade is available — this is the intended upgrade path.

  `supportsDelegation()` — new param

  - New optional param **`requireFreshStatus?: boolean`** (default `false`), same as `willDelegate`

  `executeBatchedTransaction()` / `executeDelegation()` / `executeRevokeDelegation()` — error handling and gas

  - All three actions now throw directly instead of wrapping errors. Errors:
    - `'Delegation is disabled for this address'`
    - `'Delegation requirements not satisfied on chain ${chainId}'`
  - `executeDelegation()` resolves its target contract dynamically from chain state instead of a static `DELEGATION_ADDRESSES` lookup. When the backend's `latestContract` does not match the local address mapping, resolution returns `null` and the action throws:
    - `'Delegation requirements not satisfied on chain ${chainId}'`
  - Gas estimation (when `transactionOptions.gasLimit` is `null`) now applies a buffer. Previously the raw `estimateGas` result was used directly. Standard transactions get a 20% buffer. EIP-7702 authorization transactions get the larger of 20% or a fixed 50,000 gas floor to account for authorization overhead.

  ***

  **New APIs**

  `isDelegationEnabled(address: Address): boolean` — sync

  - Returns `true` if delegation is enabled for the address, `false` if disabled.
  - Reads from the store's `disabledAddresses` set. Addresses not in the set are considered enabled.
  - Purely local — does not check backend state. Persisted only if `storeOptions` with storage is configured; otherwise resets on page reload.

  `enableDelegation(address: Address): void` — sync

  - Enables delegation for the address. Removes it from the `disabledAddresses` set.
  - Persists immediately to the store.

  `disableDelegation(address: Address): void` — sync

  - Disables delegation for the address. Adds it to the `disabledAddresses` set.
  - Persists immediately to the store. Execution actions will throw if called for a disabled address.

  `useDelegationDisabled(address: Address): boolean` — hook

  - Returns `true` when delegation is disabled for the address, `false` when enabled.
  - Subscribes to the store reactively; re-renders when `enableDelegation` or `disableDelegation` is called.

  `useWillDelegate(address: Address, chainId: number): boolean` — hook

  - Returns `true` when the next batched execution would perform delegation.
  - Fetches fresh delegation status on mount and auto-refreshes every 15 seconds.
  - Checks `isDelegationEnabled` first, then resolves the delegation decision from cached store state. Returns `true` only for the `Authorize` decision type.
  - Returns a boolean only. To get the target `DelegationContract` (address and chain), call the async `willDelegate()` action.

  ***

  **Behavior**

  Caching and staleness

  - Full delegation status (`getDelegationStatus`) is cached for **5 minutes** before re-fetching.
  - Chain-specific status (`getChainDelegationStatus`) is cached for **30 seconds**.
  - `requireFreshStatus: true` (on `willDelegate` / `supportsDelegation`) sets stale time to zero, forcing a fetch. Execution actions (`executeBatchedTransaction`, `executeDelegation`) always fetch fresh.

  Request deduplication

  - Concurrent fetches for the same address/chain pair are deduplicated in-flight. Multiple callers receive the same Promise. No time-based throttling beyond staleness checks.

  Optimistic updates

  - `executeDelegation` and `executeRevokeDelegation` write optimistic state to the store immediately after a successful transaction.
  - A **1 minute conflict window** protects optimistic writes: backend responses that contradict a recent optimistic update are rejected until the window expires. This prevents stale backend reads from reverting local state after a transaction.
  - `resetCache()` now explicitly clears optimistic update tracking alongside cached delegation data. Does not affect `disabledAddresses` preferences.

## 0.2.2

### Patch Changes

- 51e70d7: `shouldRevokeDelegation` now accepts `{ address: Address }` instead of a `WalletClient`

## 0.2.1

### Patch Changes

- 43f39a9: Add delegation support for Optimism, Arbitrum, Polygon, BSC, Katana, Ink, Unichain, Celo, Gnosis Chain, Berachain. Remove testnet chains (Sepolia, Optimism Sepolia) from default addresses.
- 43f39a9: Fix `shouldDelegate` to require backend update signal before delegating on `NOT_DELEGATED` and `THIRD_PARTY_DELEGATED` chains
- 43f39a9: Normalize addresses to EIP-55 checksum format to prevent case-sensitive key mismatches in Sets, Records, and query cache lookups.

  - Normalize API response addresses (contract, revoke, latest) via `getAddress` in the transform layer
  - Normalize user-provided addresses at every store entry point (`disableDelegation`, `enableDelegation`, `getDelegationStatus`, `getChainDelegationStatus`, `updateStatus`), the reactive `currentAddress` params path, the `delegationPreference` action, and the `useDelegationPreference`/`useDelegations` hooks

- 43f39a9: Fix optimistic `updateStatus` to promote `latestContract` to `currentContract` on delegate/upgrade, and resolve `currentContractName` for known deployments

## 0.2.0

### Minor Changes

- 356659c: Add `configure()` for dependency injection and service initialization.

  All actions now require `configure()` to be called first with required services:

  - `platformClient` — HTTP client for delegation status API requests
  - `logger` — structured logging interface (debug, info, warn, error)
  - `chains` — supported viem `Chain` objects

  Optional services:

  - `storeOptions` — async storage and sync engine for persistence
  - `currentAddress` — reactive accessor that triggers automatic pre-fetching on address changes

- 356659c: Add `executeDelegation()` and `executeRevokeDelegation()` actions (renamed from `executeBatchedTransaction` internals).

  - `executeDelegation()` — signs an EIP-7702 authorization and sends a delegation transaction. Validates user preference and delegation availability before executing, and optimistically updates local delegation state.
  - `executeRevokeDelegation()` — revokes EIP-7702 delegation by authorizing the zero address. Bypasses user preference checks since revocation is a security operation.
  - `shouldRevokeDelegation()` — checks all chains for delegations flagged for revocation (vulnerability, bug, or unspecified reasons). Returns actionable `{ address, chainId }` pairs for use with `executeRevokeDelegation()`.

- 356659c: Add `transactionType` field to `ExecutionResult` (renamed from `BatchExecutionResult`).

  The result returned by `executeBatchedTransaction()`, `executeDelegation()`, and `executeRevokeDelegation()` now includes the viem transaction type used for the submission.

- 356659c: Add `prepareBatchedTransaction()` for gas simulation before execution.

  Encodes batch calls and determines whether an EIP-7702 authorization stub should be included based on current delegation state, user preferences, and the resulting transaction type. Returns a `Transaction` object compatible with gas estimation APIs.

- 356659c: Add `willDelegate()`, `supportsDelegation()`, and `delegationPreference()` for pre-transaction delegation checks and preference management.

  - `willDelegate()` — returns whether the next batched transaction will include an EIP-7702 delegation authorization, along with the target contract address. Useful for gas estimation and first-time delegation UI prompts.
  - `supportsDelegation()` — returns whether delegation can be used for a transaction, with a reason when unsupported (`USER_DISABLED` or `NOT_AVAILABLE`).
  - `delegationPreference()` — imperative API for reading and setting per-address delegation preferences.

- 356659c: Add React hooks and `getDelegations()` backed by reactive delegation stores.

  - `useDelegations(address)` — returns `{ delegations, isLoading }` with reactive updates when delegation state changes.
  - `useDelegationPreference(address)` — returns `{ enabled, enable, disable, setEnabled }` for managing per-address delegation opt-in/out.
  - `getDelegations()` — returns all active delegations for a wallet across configured chains, filtered to `RAINBOW_DELEGATED` and `THIRD_PARTY_DELEGATED` statuses.

- 356659c: Add `resetCache()` to clear all cached delegation data, forcing fresh API lookups on the next query.

- fa40fc8: Add support for Arbitrum (42161) and Unichain (130) networks

- 3db8298: Removed deprecated utility functions:

  - `SUPPORTED_CHAINS` - Array of supported chain configurations
  - `CHAIN_LOOKUP` - Mapping of chain IDs to chain information
  - `getSupportedChainIds` - Returns array of supported chain IDs
  - `getChainInfo` - Returns chain information for a given chain ID
  - `getChainName` - Returns the name of a chain given its ID
  - `getCanDelegateWithInfo` - Returns delegation support status with chain information

- 4db3498: Adopt Rainbow-deployed delegation address for Ethereum Mainnet (1) and Base (8453) networks

## 0.1.0

### Minor Changes

- Initial release with EIP-7702 delegation and batch transaction support
- Core interface:
  - `executeBatchedTransaction()`: Executes multiple calls in a single transaction using EIP-7702 delegation
  - `encodeDelegateCalldata`: Encode batch calls into delegation contract calldata
  - `getCanDelegate()`: Check if EIP-7702 delegation is supported on a specific chain
  - `getIsDelegated()`: Check if an address is currently delegated using EIP-7702
- Supported chains:
  - Ethereum Mainnet (1)
  - Polygon (137)
  - Base (8453)
  - Optimism (10)
  - BNB Smart Chain (56)
  - Sepolia (11155111)
  - Optimism Sepolia (11155420)
