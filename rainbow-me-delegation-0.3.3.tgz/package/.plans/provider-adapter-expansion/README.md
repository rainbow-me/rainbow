# Provider Adapter Expansion

## Executive Verdict

`relay-link-poc` already proves something larger than a Relay.link integration:
it proves that the SDK can bind provider-produced execution artifacts to a
caller-owned intent, verify that binding before signing, and then reduce remote
execution into deterministic lifecycle and fallback outcomes.

That means UniswapX and CoW are not nonsense ideas here, but they are not
drop-in analogues either.

- Relay.link is an `arbitrary-call relay` plus `quote-driven cross-chain intent`
  provider.
- CoW and UniswapX are `solver-settled swap intent` providers.
- 0x spans both `gasless remote settlement` and `direct transaction quote`
  surfaces, so it is the cleanest next expansion.

The right framing is not “add more relay providers to the same contract.”
The right framing is “fix the public execution boundary, promote the demo into a
capability-scoped intent adapter system, then add providers whose capabilities
determine which scenarios they participate in.”

Read [INTENT_EXECUTION_API_REDESIGN.md](./INTENT_EXECUTION_API_REDESIGN.md)
first, then [ADAPTER_INTEGRATION_SPEC.md](./ADAPTER_INTEGRATION_SPEC.md).

## Ranked Recommendation

| Rank | Provider     | Recommendation                                              | Why it matters                                                                                                                                                                                 |
| ---- | ------------ | ----------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1    | 0x           | Build next                                                  | It cleanly demonstrates both sides of the design space: a remote gasless intent path and a direct unsigned transaction quote path, without inventing a new product story.                      |
| 2    | CoW Protocol | Build after 0x                                              | It is the strongest demonstration of solver-based intent settlement, but it requires the demo to learn partial fills and to stop assuming every provider has Relay-style sponsorship fallback. |
| 3    | UniswapX     | Build only after the shared refactor and a feasibility gate | It fits as a Dutch-auction order adapter, but the public integrator surface is less clean than CoW or 0x and it is much narrower than Relay.link in execution shape.                           |

## What “Fit” Means In This Repo

The current POC is built around four non-negotiable invariants:

1. The provider may prepare execution artifacts, but the SDK verifies the
   binding before irreversible signing or submission.
2. The adapter owns provider taxonomy mapping and normalizes provider status
   into one SDK lifecycle model.
3. Fallback policy is SDK-owned, not provider-owned.
4. Sponsorship and fee semantics are explicit, because silent downgrades are a
   product bug, not just a transport choice.

Relay.link satisfies all four in the current demo because it can prepare,
execute, and expose bundle status for both a direct sponsored raw-call flow and
a quote-driven cross-chain flow.

CoW and UniswapX only satisfy a subset:

- They are about signed trade intents, not arbitrary delegated calls.
- Their “gasless” model is embedded in solver settlement, not an explicit
  `subsidizeFees` switch that can safely degrade to direct execution.
- Their primary irreversible act is the user signing an order, not the adapter
  calling a provider `/execute` endpoint with caller-owned calldata.

That is why they fit only after the adapter contract is widened.

## Why 0x Wins First

0x is the only candidate in this set that naturally demonstrates both:

- `REMOTE_SWAP_INTENT`: the Gasless API returns approval and typed trade data,
  then owns settlement and status updates.
- `UNSIGNED_TX_QUOTE`: the Swap API returns executable transaction data for
  client-owned submission.

That makes 0x the most valuable follow-on because it lets the demo show that the
system is not limited to one relay backend, while still preserving the demo’s
existing emphasis on ownership boundaries and execution semantics.

## Why CoW Beats UniswapX As The Second Build

Both are solver-based swap-intent systems, but CoW is the stronger fit for this
repo’s problem space.

- CoW’s official SDK surface is broader and more explicit for integrators:
  quote fetching, order signing, posting, order/trade retrieval, and
  programmatic orders all exist in one official SDK family.
- CoW’s docs make the intent model explicit and expose the orderbook API as a
  first-class surface.
- CoW’s partial-fill and programmatic-order model expands the demo in a useful
  direction instead of merely duplicating “gasless swap” under a different
  brand.

UniswapX is still worthwhile, but as a narrower Dutch-order adapter rather than
the next obvious provider after Relay.link.

## Watchlist

I also considered 1inch Fusion / Fusion+ because it is closer than CoW or
UniswapX to Relay.link’s quote-driven intent story, especially for cross-chain
intents. I did not produce a plan for it in this pass because the public
integrator surface is more commercially gated and 0x already covers the most
valuable direct-plus-gasless expansion cleanly.

## Directory Contents

- [ADAPTER_INTEGRATION_SPEC.md](./ADAPTER_INTEGRATION_SPEC.md): shared adapter
  model and repo-level refactor plan.
- [INTENT_EXECUTION_API_REDESIGN.md](./INTENT_EXECUTION_API_REDESIGN.md):
  public/internal API split that removes leaked relay verification inputs from
  the released SDK surface.
- [0X_PLAN.md](./0X_PLAN.md): highest-impact next provider.
- [COW_PROTOCOL_PLAN.md](./COW_PROTOCOL_PLAN.md): solver-orderbook adapter plan.
- [UNISWAPX_PLAN.md](./UNISWAPX_PLAN.md): conditional Dutch-order adapter plan.

## Sources

- Local repo:
  - [`demo/relay-link-poc/README.md`](../demo/relay-link-poc/README.md)
  - [`demo/relay-link-poc/backend/adapter/types.ts`](../demo/relay-link-poc/backend/adapter/types.ts)
  - [`demo/relay-link-poc/shared/scenarioCore.ts`](../demo/relay-link-poc/shared/scenarioCore.ts)
  - [`src/actions/internal/preflightRelay.ts`](../src/actions/internal/preflightRelay.ts)
  - [`src/actions/internal/relayExecution.ts`](../src/actions/internal/relayExecution.ts)
  - [`src/relay/lifecycle.ts`](../src/relay/lifecycle.ts)
  - [`src/relay/transport.ts`](../src/relay/transport.ts)
- 0x:
  - <https://0x.org/docs/0x-gasless-api/introduction>
  - <https://0x.org/docs/0x-gasless-api/guides/get-started-with-gasless-api>
  - <https://0x.org/docs/0x-swap-api/introduction>
- CoW Protocol:
  - <https://docs.cow.fi/cow-protocol/concepts/introduction/intents>
  - <https://docs.cow.fi/cow-protocol/reference/apis/orderbook>
  - <https://github.com/cowprotocol/cow-sdk>
  - <https://github.com/cowprotocol/services>
- UniswapX:
  - <https://docs.uniswap.org/contracts/uniswapx/overview>
  - <https://github.com/Uniswap/UniswapX>
  - <https://github.com/Uniswap/uniswapx-service>
