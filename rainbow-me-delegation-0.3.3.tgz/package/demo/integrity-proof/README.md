# Integrity Proof Demo

Interactive browser demo showing why client verification before signing must compare backend prepare bindings to a local intent digest.

Primary architecture reference:

- `demo/integrity-proof/RELAY_INTEGRITY_ARCHITECTURE.md` — single definitive document covering the integrity model, concrete example, digest coverage, and attack scenarios

Supporting documents:

- `demo/integrity-proof/SECURE_RELAY_MASTER_BRIEF.md` — decision brief
- `demo/integrity-proof/CROSS_CHAIN_MARKET_BUY_EXAMPLE.md` — cross-chain example context
- `demo/integrity-proof/CROSS_CHAIN_MARKET_BUY_FLOW_ADDENDUM.md` — exact payload walkthrough
- `demo/integrity-proof/RELAY_MODEL_CAPABILITY_CONSTRAINT_MAP.md` — Model IB vs Model SB capability map
- `demo/integrity-proof/DEMO_OVERVIEW_FOR_IVAN_BENJAMIN.md` — outcome matrix for all scenarios

## Run

1. Build and serve the folder:

```bash
cd /Users/christian/dev/delegation
yarn demo:integrity
```

2. Open the URL printed in terminal (starts at `http://localhost:4173` and automatically retries higher ports if busy).

## TypeScript Source

- Source of truth: `demo/integrity-proof/app.ts`
- Browser runtime file: `demo/integrity-proof/.build/app.js` (generated)
- Local relayer server source: `demo/integrity-proof/server.ts`

`demo/integrity-proof/.build/*` is build output and not source.

After editing `app.ts`, rebuild with:

```bash
yarn --cwd demo/integrity-proof build
```

To generate a compressed deployable static bundle (without changing `.build`):

```bash
yarn --cwd demo/integrity-proof build:deploy
```

This writes:

- `demo/integrity-proof/.deploy/index.html`
- `demo/integrity-proof/.deploy/styles.css`
- `demo/integrity-proof/.deploy/app.js`

The deploy bundle is self-contained: if `/api/relay/*` is unavailable, the app automatically switches to an embedded in-browser relayer runtime using the same prepare/execute/getStatus model.

## Demo Flow

1. Pick an **Intent Profile** (`Settlement Batch`, `Swap Route`, `Cross-Chain Market Buy`, `NFT Mint Batch`, `Authority Update`, `Sponsored Bridge`).
2. Pick a **Backend Behavior** (`Honest backend`, `Fee inflation`, `Fee inflation within cap`, `Recipient hijack`, `Call injection`, `Chain context tamper`, `Quote signer rewrite`, `Request-id replay`).
3. Click **Run Replay**.
4. Compare outcomes:
   - `Structural Checks`: package checks only, without local binding comparison.
   - `SDK Verification`: local digest recomputation plus signed-binding comparison.
   - `Execute API`: backend execute-time self-consistency checks.
5. Inspect evidence in the bottom console tabs:
   - `INTENT`: canonical local intent payload + digests.
   - `ALL CHECKS`: check-by-check outcomes across structural, SDK, and execute layers.

The key interaction pattern is that verifier logic stays the same while intent shape changes, with integrity attacks first and fee/type guardrail controls shown separately.
