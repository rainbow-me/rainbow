# Relay Link POC

Interactive demo and scenario runner for the Relay.link integration built on the worker-owned execution model.

## What it proves

The POC is meant to show the full path, not just a happy-path API call:

- direct raw-call execution
- quote-driven crosschain Relay sessions
- quote-driven permit flows
- SDK integrity failures before user commitment
- deterministic fallback behavior

Every run exposes the same ownership split the production model depends on:

- provider
- worker adapter
- SDK
- wallet request

## Layout

- `backend/adapter`: adapter over the relay-reference worker API
- `backend/scenarios.ts`: scenario runner and scenario-specific quote planning
- `backend/server.ts`: local API and static file server
- `ui/`: scenario UI
- `RESULTS.md`: run report
- `evidence/reference.json`: tracked reference evidence snapshot
- `evidence/local/latest-run.json`: ignored local run output

## Scenarios

- `Live Sponsored Delegation`
- `Live Relay Quote`
- `Base USDC Permit Swap`
- `Fallback Scenarios`
- `Domain/Identity Tamper Fail-Closed`
- `Fee Inflation Within Structural Cap`

The live quote scenario needs Base ETH. The permit swap scenario needs Base USDC.

## Wallet source

Wallet source resolution is:

1. `DEMO_WALLET_PRIVATE_KEY`
2. browser-generated key
3. file fallback at `demo/relay-link-poc/.wallet.json` for non-API flows

API routes intentionally disable file fallback so one backend process does not silently share one wallet across users.

The browser creates and stores a demo key only when a scenario requires a local wallet request.

## Run

Recommended:

```bash
yarn demo:relay-link-poc
```

Manual flow:

```bash
yarn --cwd demo/relay-link-poc build
set -a && source .env.local && set +a
yarn --cwd demo/relay-link-poc scenarios
set -a && source .env.local && set +a
yarn --cwd demo/relay-link-poc serve
```

To refresh the tracked reference snapshot explicitly:

```bash
yarn --cwd demo/relay-link-poc scenarios:reference
```

The UI loads `evidence/reference.json` on boot. Ordinary local runs write `evidence/local/latest-run.json`.

Open the `http://localhost:<port>` URL printed by the server.

## Prerequisites

- Node 22 commands (`npx -y node@22 ...`)
- either:
  - `RELAY_REFERENCE_GATEWAY_URL` and `RELAY_REFERENCE_QUOTE_SIGNER`
  - or a local relay-reference stack started with `yarn workers:relay-reference:dev`

The backend can auto-discover a local worker stack from `workers/relay-reference/.dev-stack.json`.

## Deploy

```bash
yarn --cwd demo/relay-link-poc build:deploy
```

That command builds `demo/relay-link-poc/.deploy` as a static bundle for deployment.

## Tests

```bash
yarn --cwd demo/relay-link-poc test
```
