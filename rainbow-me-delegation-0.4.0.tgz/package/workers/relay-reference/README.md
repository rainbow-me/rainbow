# Relay Backend Reference

Reference Cloudflare Workers backend for the SDK's relay service.

## Components

- `gateway/`: public worker that serves the relay HTTP API and routes execution state into the Durable Object
- `signer/`: internal signing worker used through a service binding
- `shared/`: worker-shared contracts and types

Public routes:

- `POST /v1/executions/prepare`
- `POST /v1/executions/{executionId}/execute`
- `POST /v1/executions/{executionId}/wallet-results`
- `GET /v1/executions/{executionId}/status`

Further detail lives in:

- [reference gateway architecture](../../architecture-docs/relay/2-reference-gateway.md)
- [`DEPLOYMENT.md`](DEPLOYMENT.md)

## Local development

Copy the local env templates:

```bash
cp workers/relay-reference/signer/.dev.vars.example workers/relay-reference/signer/.dev.vars.development
cp workers/relay-reference/gateway/.dev.vars.example workers/relay-reference/gateway/.dev.vars.development
```

Set the signer private key in `signer/.dev.vars.development` and the matching `QUOTE_SIGNER_ADDRESS` plus `RELAY_LINK_API_KEY` in `gateway/.dev.vars.development`.

Development disables external reporting even if these keys are present:

- `GATEWAY_API_KEY` for platform relayed-transaction ingestion
- `DATADOG_API_KEY` for Datadog terminal execution metrics

Then start the stack:

```bash
yarn workers:dev
```

The launcher uses the Wrangler `development` environment by default, validates the signer/address match, and writes `workers/relay-reference/.dev-stack.json` for local consumers.

To test external reporting locally, run the stack in staging instead:

```bash
yarn workers:dev -- --env staging
```

## Validation

Run from repo root:

```bash
yarn typecheck:workers:relay-reference:gateway
yarn typecheck:workers:relay-reference:signer
yarn test:workers:relay-reference:gateway
```

If you want to run the gateway tests from inside `workers/relay-reference/gateway`, use `yarn test`.

## Deploy

See [`DEPLOYMENT.md`](DEPLOYMENT.md).
