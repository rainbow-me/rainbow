import {
  Address,
  encodeFunctionData,
  parseAbi,
  PublicClient,
  WalletClient,
  Authorization,
  Chain,
} from "viem";

import { mainnet, polygon, base, optimism, bsc, sepolia } from '@wagmi/chains';

// Export supported chains for easy access
export const SUPPORTED_CHAINS = {
  mainnet,
  polygon, 
  base,
  optimism,
  bsc,
  sepolia,
} as const;

// Create a lookup map for chain ID to chain object
const CHAIN_LOOKUP: Record<number, Chain> = {
  [mainnet.id]: mainnet,
  [polygon.id]: polygon,
  [base.id]: base,
  [optimism.id]: optimism,
  [bsc.id]: bsc,
  [sepolia.id]: sepolia,
};

// Constants for delegation addresses across different chains
export const DELEGATION_ADDRESSES: Record<number, string> = {
  [mainnet.id]: "0x000000009B1D0aF20D8C6d0A44e162d11F9b8f00",      
  [polygon.id]: "0x000000009B1D0aF20D8C6d0A44e162d11F9b8f00",    
  [base.id]: "0x000000009B1D0aF20D8C6d0A44e162d11F9b8f00",   
  [optimism.id]: "0x000000009B1D0aF20D8C6d0A44e162d11F9b8f00",     
  [bsc.id]: "0x000000009B1D0aF20D8C6d0A44e162d11F9b8f00",
  [sepolia.id]: "0x000000009B1D0aF20D8C6d0A44e162d11F9b8f00", 
  [11155420]: "0x000000009B1D0aF20D8C6d0A44e162d11F9b8f00", 
};

// Helper to get all supported chain IDs
export const getSupportedChainIds = (): number[] => {
  return Object.keys(DELEGATION_ADDRESSES).map(Number);
};

// Helper to get chain info by ID
export const getChainInfo = (chainId: number): Chain | null => {
  return CHAIN_LOOKUP[chainId] || null;
};

// Helper to get chain name by ID
export const getChainName = (chainId: number): string => {
  const chain = getChainInfo(chainId);
  return chain?.name || `Chain ${chainId}`;
};

// Minimal delegation ABI for executing batched calls
export const minimalDelegationExecAbi = parseAbi([
  "function execute(((address to,uint256 value,bytes data)[] calls,bool revertOnFailure) batched) returns(bytes[])",
]);

// Types
export interface BatchCall {
  to: Address;
  value: bigint;
  data: `0x${string}`;
}

export interface BatchExecutionResult {
  txHash?: `0x${string}`;
}

export interface TransactionGasParamAmounts {
  maxFeePerGas: string;
  maxPriorityFeePerGas: string;
  gasLimit: bigint | null;
}

export interface ExecuteBatchedTransactionParams {
  calls: BatchCall[];
  walletClient: WalletClient;
  publicClient: PublicClient;
  transactionOptions: TransactionGasParamAmounts;
}

/**
 * Check if delegation is supported on the given chain
 */
export const getCanDelegate = (chainId: number): boolean => {
  // Validate input is a valid number
  if (typeof chainId !== 'number' || isNaN(chainId) || !Number.isInteger(chainId)) {
    return false;
  }
  
  return DELEGATION_ADDRESSES[chainId] !== undefined;
};

/**
 * Check if delegation is supported on the given chain (with detailed info)
 */
export const getCanDelegateWithInfo = (chainId: number): { 
  canDelegate: boolean; 
  chainName: string; 
  delegationAddress?: string 
} => {
  const canDelegate = getCanDelegate(chainId);
  const chainName = getChainName(chainId);
  const delegationAddress = canDelegate ? DELEGATION_ADDRESSES[chainId] : undefined;
  
  return { canDelegate, chainName, delegationAddress };
};

/**
 * Check if an address is currently delegated using EIP-7702
 */
export const getIsDelegated = async ({
  address,
  chainId,
  publicClient,
}: {
  address: Address;
  chainId: number;
  publicClient: PublicClient;
}): Promise<boolean> => {
  const code = await publicClient.getCode({ address: address });
  const delegationAddress = DELEGATION_ADDRESSES[chainId];
  if (!delegationAddress) return false;
  
  const indicator = `0xef0100${delegationAddress.slice(2).toLowerCase()}`;
  return code?.toLowerCase() === indicator;
};

export const encodeDelegateCalldata = async (calls: BatchCall[]) => {
  const delegateCalldata = encodeFunctionData({
    abi: minimalDelegationExecAbi,
    functionName: 'execute',
    args: [{ calls, revertOnFailure: true }],
  });
  return delegateCalldata;
};

/**
 * Execute batched transactions with optional EIP-7702 delegation
 * 
 * @param params - Configuration object containing calls, clients, and options
 * @returns Transaction result with delegation status information
 */
export const executeBatchedTransaction = async ({
  calls,
  walletClient,
  publicClient,
  transactionOptions
}: ExecuteBatchedTransactionParams): Promise<BatchExecutionResult> => {
  if (!walletClient.account) {
    throw new Error("Wallet client must have an account");
  }

  if (!calls || calls.length === 0) {
    throw new Error("At least one call must be provided");
  }

  const userAddress = walletClient.account.address;
  const chainId = await publicClient.getChainId();
  const chainName = getChainName(chainId);
  const chain = walletClient.chain;
  const delegateCalldata = await encodeDelegateCalldata(calls);

  const delegationAddress = DELEGATION_ADDRESSES[chainId] as Address;

  let auth: Authorization | undefined;

  try {
    // Sign authorization if not already delegated
    auth = await walletClient.signAuthorization({
      account: walletClient.account,
      contractAddress: delegationAddress,
      executor: "self",
    });
  } catch (error) {
    throw new Error(`Failed to sign authorization for ${chainName} (chain ${chainId}): ${error}`);
  }

  try {
    let gasLimit = transactionOptions?.gasLimit;
    if (!gasLimit) {
      gasLimit = await publicClient.estimateGas({
        account: walletClient.account,
        to: userAddress,
        data: delegateCalldata,
        authorizationList: [auth],
      });
    }
    // Send the transaction
    const txHash = await walletClient.sendTransaction({
      account: walletClient.account,
      chain,
      to: userAddress,
      data: delegateCalldata,
      gas: gasLimit,
      maxFeePerGas: BigInt(transactionOptions.maxFeePerGas),
      maxPriorityFeePerGas: BigInt(transactionOptions.maxPriorityFeePerGas),
      authorizationList: [auth],
    });

    return {
      txHash,
    };
  } catch (error) {
    throw new Error(`Failed to execute batched transaction on ${chainName} (chain ${chainId}): ${error}`);
  }
};