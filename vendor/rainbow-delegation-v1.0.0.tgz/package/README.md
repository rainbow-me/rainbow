# Rainbow Delegation

[![npm version](https://badge.fury.io/js/rainbow-delegation.svg)](https://www.npmjs.com/package/rainbow-delegation)
[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)

EIP-7702 batch transaction executor with delegation detection. This package provides utilities to execute batched transactions using EIP-7702 delegation, with automatic fallback for non-supporting chains.

## Installation

```bash
yarn add rainbow-delegation
# or
npm install rainbow-delegation
# or
pnpm add rainbow-delegation
```

**Peer Dependencies:**
```bash
yarn add viem@^2.0.0
```

## Quick Start

```typescript
import { executeBatchedTransaction } from 'rainbow-delegation';
import { createWalletClient, createPublicClient, http } from 'viem';
import { mainnet } from 'viem/chains';
import { privateKeyToAccount } from 'viem/accounts';

// Setup clients
const account = privateKeyToAccount('0x...');
const publicClient = createPublicClient({
  chain: mainnet,
  transport: http()
});
const walletClient = createWalletClient({
  account,
  chain: mainnet,
  transport: http()
});

// Define your batch calls
const calls = [
  {
    to: '0x...', // Token contract
    value: 0n,
    data: '0x...' // approve() calldata
  },
  {
    to: '0x...', // DEX contract  
    value: 0n,
    data: '0x...' // swap() calldata
  }
];

// Execute batched transaction
const result = await executeBatchedTransaction({
  calls,
  walletClient,
  publicClient,
  revertOnFailure: true
});

console.log('Transaction hash:', result.txHash);
console.log('Was delegated:', result.isDelegated);
console.log('Authorization used:', result.authorizationUsed);
```

## API Reference

### `executeBatchedTransaction(params)`

Executes multiple calls in a single transaction using EIP-7702 delegation when possible.

**Parameters:**
```typescript
interface ExecuteBatchedTransactionParams {
  calls: BatchCall[];
  walletClient: WalletClient;
  publicClient: PublicClient;
  revertOnFailure?: boolean; // default: true
}

interface BatchCall {
  to: Address;
  value: bigint;
  data: `0x${string}`;
}
```

**Returns:**
```typescript
interface BatchExecutionResult {
  txHash?: `0x${string}`;        // Single tx hash (delegated)
  txHashes?: `0x${string}`[];    // Multiple tx hashes (sequential)
  receipt?: any;                 // Single receipt (delegated)
  receipts?: any[];              // Multiple receipts (sequential)
  isDelegated: boolean;          // Whether delegation was used
  authorizationUsed?: boolean;   // Whether new authorization was signed
}
```

### `getCanDelegate(chainId)`

Check if EIP-7702 delegation is supported on a specific chain.

```typescript
const canDelegate = getCanDelegate(1); // true for Ethereum mainnet
```

### `getIsDelegated({ address, chainId, publicClient })`

Check if an address is currently delegated using EIP-7702.

```typescript
const isDelegated = await getIsDelegated({
  address: '0x...',
  chainId: 1,
  publicClient
});
```

## Supported Chains

| Chain | Chain ID | Status |
|-------|----------|--------|
| Ethereum Mainnet | 1 | ✅ |
| Polygon | 137 | ✅ |
| Base | 8453 | ✅ |
| Optimism | 10 | ✅ |
| BSC | 56 | ✅ |
| Sepolia | 11155111 | ✅ |
| Optimism Sepolia | 11155420 | ✅ |

## How It Works

1. **Chain Detection**: Checks if the current chain supports EIP-7702 delegation
2. **Delegation Check**: Verifies if the sender address is already delegated  
3. **Smart Execution**:
   - If **not delegated**: Signs authorization + executes batch via delegation
   - If **already delegated**: Executes batch directly (no authorization needed)
   - If **chain unsupported**: Falls back to sequential transactions

4. **Transaction Types**:
   - **EIP-7702 Transaction** (type 0x04): When authorization is needed
   - **Regular Transaction** (type 0x02): When already delegated
   - **Sequential Transactions**: When delegation is unsupported

## Examples

### Token Approval + Swap

```typescript
import { encodeFunctionData } from 'viem';
import { executeBatchedTransaction } from 'rainbow-delegation';

const calls = [
  // Approve tokens
  {
    to: tokenAddress,
    value: 0n,
    data: encodeFunctionData({
      abi: erc20Abi,
      functionName: 'approve',
      args: [spenderAddress, amount]
    })
  },
  // Execute swap
  {
    to: dexAddress,
    value: 0n,
    data: encodeFunctionData({
      abi: dexAbi,
      functionName: 'swapExactTokensForTokens',
      args: [amount, minOut, path, to, deadline]
    })
  }
];

const result = await executeBatchedTransaction({
  calls,
  walletClient,
  publicClient
});
```

### Multi-Send ETH

```typescript
const calls = [
  { to: '0xAlice...', value: parseEther('0.1'), data: '0x' },
  { to: '0xBob...', value: parseEther('0.2'), data: '0x' },
  { to: '0xCharlie...', value: parseEther('0.05'), data: '0x' }
];

const result = await executeBatchedTransaction({
  calls,
  walletClient,
  publicClient
});
```

## Usage

```typescript
import { 
  executeBatchedTransaction, 
  waitForBatchReceipts,
  getCanDelegate 
} from '@rainbow-me/rainbow-delegation';
import { createWalletClient, createPublicClient, http } from 'viem';
import { mainnet } from 'viem/chains';

// Create clients
const walletClient = createWalletClient({
  chain: mainnet,
  transport: http(),
  account: privateKeyToAccount('0x...'), // Your private key
});

const publicClient = createPublicClient({
  chain: mainnet,
  transport: http(),
});

// Check if delegation is supported
const canDelegate = getCanDelegate(mainnet.id);
console.log(`Delegation supported on mainnet: ${canDelegate}`);

// Execute batch transaction (returns immediately with tx hash(es))
const result = await executeBatchedTransaction({
  calls: [
    {
      to: '0x742...abc', // Contract address
      data: '0x123...def', // Encoded function call
      value: 0n,
    },
    {
      to: '0x456...789',
      data: '0xabc...123',
      value: 100000000000000000n, // 0.1 ETH
    }
  ],
  walletClient,
  publicClient,
  revertOnFailure: true, // Optional: default true
});

console.log('Transaction(s) submitted:', result.txHash || result.txHashes);
console.log('Is delegated:', result.isDelegated);

// Optionally wait for receipts when needed
const { receipt, receipts } = await waitForBatchReceipts(result, publicClient);
console.log('Transaction(s) confirmed:', receipt || receipts);
```

### Key Features
- **Delegation detection**: Automatically uses EIP-7702 when supported and beneficial
- **Automatic fallback**: Falls back to sequential transactions on unsupported chains

## Development

```bash
# Install dependencies
yarn install

# Build the package
yarn build

# Run tests
yarn test

# Type check
yarn typecheck

# Watch mode
yarn dev
```

## License

GPL-3.0 © Rainbow

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request. By contributing to this project, you agree that your contributions will be licensed under the GPL-3.0 license.

## Links

- [EIP-7702 Specification](https://eips.ethereum.org/EIPS/eip-7702)
- [Viem Documentation](https://viem.sh)
- [GitHub Repository](https://github.com/rainbow-me/rainbow-delegation) 